# Changelog

All notable changes to Greedy Meshing are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Fixed
- **Merged faces rendering as one flat colour with ColorLight (GPU pipeline)**: ColorLight redirects
  Sodium's terrain pipelines to its own copy of the shader (`colorlight:blocks/colored_terrain`), so
  the greedy UV patch never reached it. The patch now also applies to that shader. Two related
  problems in the injected code are fixed with it: the atlas sampler is now picked by name
  (`u_BlockTex`) instead of "first `sampler2D`", which in ColorLight's copy is the 16x16 lightmap,
  and the face marker carried in vertex alpha is cleared from ColorLight's `v_ColorBase` too.
- **ColorLight in vertex-colour mode** (pipeline switched off, unsupported Sodium build, or an Iris
  pack active): merged quads bypass the model where ColorLight bakes its colour, so they came out
  uncoloured. Blocks next to coloured light now stay on the per-block path in that mode; light-free
  areas still merge. No effect while the GPU pipeline is active or ColorLight is absent.

### Performance (Sodium path)
- The per-thread work state is kept between section builds instead of being removed after each one,
  which reallocated about 200 KiB of arrays per section.
- Face visibility, AO merge keys and per-corner smooth lighting read neighbouring blocks, light and
  occlusion through a lazily filled 18x18x18 per-section cache instead of the world slice.
- Face layers (model walk, sprite lookup) are cached per block state and face until resources reload.
- Per-block eligibility checks are memoised for runs of the same block state.
- The merge sweep groups faces with a small hash table instead of scanning every group per cell.

## [0.6.1]

### Fixed
- **Overlay/CTM resource packs disabling greedy meshing almost everywhere** (issue #20): packs such
  as Matcha Block Overlays list hundreds of terrain blocks in their `optifine/ctm` properties, and
  every listed block was excluded from merging at any distance. With Min Merge Distance set, those
  blocks now merge beyond the zone while sections inside it keep rendering per-block, so the pack's
  overlays stay intact up close. With Min Merge Distance at 0 the exclusion is unchanged unless
  the new **Merge CTM Blocks** option (off by default, in the Cloth and Sodium settings) is on,
  which merges those blocks at any distance.

- **Chunk build lost to a null-pointer crash on 26.x** (issue #21): a model quad with a tint index
  the block has no tint source for (seen with resource-pack models) made the merged-quad tint
  lookup throw, discarding the section's greedy geometry and leaving the old mesh in place. A
  missing tint source is now treated as untinted, as the pre-26 path already did.

- **Sodium settings not following changes made in the Cloth/Mod Menu screen**: on the new Sodium
  config API the Greedy Meshing page kept the values from when it was registered, so it showed
  stale settings after a save from the Cloth screen and could write them back over it. It now
  re-reads the saved settings after every save.

## [0.6.0]

### Added
- **Minecraft 26.3 support** (vanilla renderer and Sodium 0.9.2). 26.3 renamed Blaze3D to
  renderpearl and compiles shaders through SPIR-V, so the terrain shader overrides were ported to
  the new `#include` / explicit `layout(location)` format (including the new multidraw and OIT
  variants), and the Sodium shader injection now gives its varyings explicit locations. Smooth
  lighting follows vanilla's switch to `BlockState.isLightPermeable()` for AO occlusion. VulkanMod
  has no 26.3 release yet.
- **Min Merge Distance** (issue #19): sections within this many chunks of the player render
  per-block instead of merged, hiding merged-quad texture-rotation artifacts up close while distant
  terrain keeps the savings. The zone follows the player: crossing a chunk boundary rebuilds only
  the sections whose near/far status changed. Available in the Cloth Config screen and in Sodium's
  settings (both API generations). Off (0) by default; shown in the F3 settings summary when set.

## [0.5.7]

### Fixed
- **Doubled/offset block faces at merged-quad corners with Aggressive Greedy enabled**: GPU Crack
  Fix's outer-edge nudge was being applied at genuine block-corner silhouette edges, not just at
  seams between separately-meshed quads, pushing the face past its true boundary into the
  perpendicular face's space. It now only nudges an edge that borders a real section boundary or
  more visible same-direction geometry. (fixes #18)

## [0.5.6]

### Fixed
- **Debug wireframe/triangles persisting after breaking the last block in a chunk section**: when a
  section becomes fully empty, the renderer skips recompiling it, so stale debug overlays were never
  cleared. The debug store now prunes entries for all-air sections periodically. (fixes #16)
- **Debug triangles not rendering when wireframe or comparison is also enabled**: triangles can now
  be shown alongside wireframe and comparison overlays simultaneously. (fixes #17)

## [0.5.5]

### Changed
- **GPU Crack Fix now costs effectively no geometry**: rather than forcing a merged quad's visible
  faces all the way down to per-block subdivision, it now nudges just the quad's outer-boundary
  vertices outward by a small epsilon, hiding the same view-dependent raster gap by slightly
  overlapping neighboring geometry instead of adding triangles. Re-enabled by default (previously
  turned off due to its geometry cost); also confirmed present on some desktop GPUs (e.g. Apple
  M-series), not just mobile, so it's no longer gated to detected mobile renderers.

### Fixed
- **OptiFine-format connected/random textures (e.g. via Continuity) rendering incorrectly once
  merged**: blocks referenced by a resource pack's `matchBlocks`/`matchTiles` CTM or random-texture
  properties are now excluded from greedy merging, since their real texture is chosen per-position
  from neighboring blocks and a single merged quad can't reproduce that. Detected by parsing the
  pack's own properties files rather than a CTM mod's internal classes.
- **Settings not visibly applying via Sodium's native options menu**: toggles like Merge Oriented
  Blocks now correctly invalidate sprite-eligibility state when applied from Sodium's own settings
  screen (both API generations), not just the standalone Mod Menu / Cloth Config screen.

### Improved
- **F3 debug overlay**: quad/vertex counts now reflect currently loaded terrain instead of
  lifetime cumulative totals, so the numbers actually move after a setting change. Added lines for
  active non-default settings, the detected renderer backend (Vanilla/Sodium/VulkanMod), and how
  many blocks are currently excluded from merging due to connected/random textures.

## [0.5.4]

### Fixed
- **Full Sodium dual-API settings support on Minecraft 1.21.1**: the same jar once again includes
  both the legacy Sodium 0.6.x options mixin and the `sodium:config_api_user` implementation used
  by the concurrent Sodium 0.8.x beta line. The two API artifacts are kept under distinct compile
  coordinates so Gradle cannot collapse them, restoring 0.5.1's integration without reintroducing
  0.5.3's startup crash.
- **View-dependent sky-colored holes on MobileGlues/Adreno terrain** (issue #14): affected mobile
  renderers now use crack-safe per-block subdivision for visible merged faces, eliminating raster
  gaps between differently sized greedy quads. This intentionally reduces the visible-geometry
  optimization on MobileGlues and may increase chunk-build/render cost there compared with 0.5.35;
  it is a correctness-first compatibility fallback enabled by the new **Mobile GPU Crack Fix**
  option. Users whose device renders correctly can disable it to restore maximum geometry
  reduction. Desktop and other renderers keep the normal four-block subdivision regardless.
- **Greedy texture sampling at atlas and cutout boundaries**: reconstructed UVs are clamped inside
  their sprite, face metadata no longer reduces texture alpha, and stable gradients are used across
  the vanilla, Sodium, and VulkanMod shader paths.
- **Over-dark merged faces near lighting boundaries**: default merging now includes block-light and
  sky-light levels in its compatibility key, preventing a dark corner from being interpolated
  across a brighter run. Aggressive Greedy retains its existing performance-first behavior.

## [0.5.35]

### Fixed
- **Crash on 1.21.1 with Sodium's 0.8.x beta line** (issue #13): 0.5.3's build-conflict fix stopped
  compiling the mod's Sodium options page against the new config API for 1.21.1, but still declared
  it as Sodium's `sodium:config_api_user` entrypoint, crashing on launch for anyone on that branch.
  The entrypoint declaration is now dropped for 1.21.1; Mod Menu / Cloth Config still expose the same
  settings there. Full dual-API support (matching 0.5.1's behavior before the 0.5.3 regression) is
  planned for a follow-up release.

## [0.5.3]

### Fixed
- **Distant ore flicker**: greedy terrain UV sampling now uses stable block-position gradients
  across 1.21.x and 26.2 instead of derivatives from discontinuous `fract()` coordinates.
- **Emissive ore depth fighting**: `_e` overlays now remain separated from their base faces at long
  distance, preventing camera-movement flicker.
- **1.21.1 Sodium build compatibility**: the release build now follows the primary stable Sodium
  API pin without resolving incompatible legacy and new option APIs together.

## [0.5.2]

### Fixed
- **Faithful 64x and other high-resolution resource packs**: merged terrain now reconstructs 16x,
  32x, and 64x sprite UVs correctly across vanilla, Sodium, and Vulkan shader paths.
- **OptiFine-style emissive textures**: `_e` overlays now preserve transparent pixels and use the
  correct cutout material, preventing stretched or fullbright backgrounds on glowing ores.
- **Resource-pack emissive atlas compatibility** across the 1.21.x and 26.x atlas APIs.
- **Light-emitting blocks behind translucent faces** now retain their own lightmap sampling.

## [0.5.1]

### Fixed
- **Sodium options page missing on 1.21.1's 0.8.x beta branch** (issue #9's underlying cause):
  Sodium now also ships a concurrent 0.8.x release line for 1.21.1 itself, not just newer Minecraft
  versions, so the mod's old/new Sodium-API detection was keyed on Minecraft version and wrongly
  assumed 1.21.1 could only ever have the pre-0.8 `SodiumOptionsGUI` API. Detection is now driven by
  each Minecraft version's actual pinned Sodium version(s), and 1.21.1 compiles both the legacy
  mixin and the new `sodium:config_api_user` entrypoint into the same jar, so whichever Sodium line
  is actually installed gets a working options page instead of a silent `ClassNotFoundException`.
- **Merged blocks rendering with wrong/tiled textures after a resource pack swap** (e.g. switching
  to a higher-resolution pack like Faithful 64x): eligibility and sprite-compatibility verdicts are
  cached per `BlockState`, but nothing invalidated that cache when the active resource pack changed
  — only reopening the mod's own config screen did, as an unintended side effect of applying
  settings. A resource-reload listener now clears both caches and forces a re-render on every
  resource pack change, not just when the config screen is touched.

### Added
- **Merge Oriented Blocks** is now exposed on Sodium's own in-game options page (both the legacy and
  new Sodium config APIs), matching the existing Mod Menu / Cloth Config toggle.

## [0.5.0]

### Performance
- **Chunk-build cost of the greedy sweep is now proportional to visible faces**
  rather than a flat cost per section. The binary keyed sweep previously probed
  all 4096 cells of every one of the six faces (24,576 probes per section) no
  matter how few faces were actually visible. It now walks only the set bits of
  the visibility mask, buckets them by depth slice, and skips empty slices
  entirely. Emission order is unchanged (ascending block index within a depth
  slice is exactly the old row-major order), so this is a pure speedup with no
  effect on rendered output.
- **Fully culled faces are skipped up front** via a mask emptiness check,
  avoiding per-slice setup for the six-faces-culled case that dominates interior
  and underground sections.
- **Merge-group lookup checks the previous group first.** Runs of one block state
  are the common case, which turns the linear scan over active groups into a
  single comparison for most cells.
- **Quad output list is pre-sized**, removing repeated array-copy growth from the
  default capacity of 10 on chunk-build threads.

### Added
- F3 overlay now reports vertices removed and an estimated vertex-memory saving
  for currently loaded terrain, alongside the existing cumulative quad counts.
  Tracked per-section (added on build, removed on rebuild/unload-by-distance)
  rather than accumulated for the whole session, so the figure reflects what's
  actually loaded right now rather than climbing forever as you play. Vertex
  count is exact; the byte figure assumes the vanilla 32-byte stride and is an
  upper bound (Sodium packs smaller), so it is labelled as an estimate.
- **Merge Oriented Blocks** (experimental, off by default): allows blocks
  carrying a `facing`/`axis`/`rotation` property to merge, provided their baked
  model is verified, by comparing baked UVs against exactly the mapping
  `terrain.fsh` reconstructs, to be a plain six-face cube. Previously any such
  property disqualified a block outright as a blunt proxy for "the model might
  not be six plain faces," which excludes plenty of blocks (particularly
  modded ones) that are. Raises the merge rate on normal terrain, where
  eligibility was weakest. Report any block that renders wrong once merged.

## [0.4.2]

### Fixed
- **Milkshade Dynamics compatibility** (issue #5): recognize Milkshade's
  replacement Sodium terrain shader and apply Greedy Meshing's UV-retiling
  patch to it, preventing merged block faces from rendering as flat colors.

## [0.4.1]

### Fixed
- **Top/bottom texture flip on merged quads** (issue #7): the shader-side UV
  reconstruction used for greedy-merged UP/DOWN faces had those two faces' V
  mapping swapped relative to Minecraft's actual cube-UV convention, mirroring
  the texture on every merged top/bottom face. Most visible where a merged face
  bordered an unmerged neighbor of a different block variant (e.g. a stone brick
  slab next to a stone brick block).
- **Sodium 0.8+ startup mixin crash**: `SodiumOptionsGUIMixin` compiles to a
  no-op class with no `@Mixin` annotation on Sodium 0.8+ (config now registers
  through the `sodium:config_api_user` entrypoint instead), which Mixin's loader
  treated as a hard `InvalidMixinException` regardless of `"required": false`.
  The entry is now dropped from the mixin config on those versions instead of
  just being marked optional.

## [0.4.0]

### Added
- **Sodium options integration** for Greedy Meshing settings, including support for
  running without Cloth Config / Mod Menu installed.
- **Debug options on Sodium's options page** for easier runtime diagnosis and
  comparison workflows.

### Fixed
- **Rotated full-cube model correctness** (issue #6): orientation-bearing block
  states (`facing`, `axis`, `rotation`) are excluded from greedy capture so their
  baked-model geometry stays on the normal renderer path.
- **Weird visual artifacts / average-color-style faces** (issue #5): greedy capture
  now skips blocks whose face sprites are not compatible with the greedy UV
  reconstruction path, keeping those blocks on vanilla/Sodium/Vulkan normal render
  paths.
- **Sodium 0.8+ options wiring regressions** where some boolean options lacked
  required default values.
- **Sodium 0.8+ startup/ClassNotFound crash path** by providing the expected mixin
  target class presence in newer API layouts.

### Changed
- **Greedy Water on 26.x** is now disabled in the runtime path to avoid known
  renderer-specific artifacts on that line.

## [0.3.0]

### Added
- **Greedy Water (flat still-water merging)** for supported renderer/version paths.
- **Sable compatibility** adjustments for sub-level shading behavior.
- **Dev renderer switch** (`-Prenderer=sodium|vulkanmod|vanilla`) to simplify
  runtime-path testing without editing project properties.

### Fixed
- **Modrinth listing/version metadata** so Minecraft 26.2 is featured correctly
  instead of appearing as all-version coverage.
- **Build dependency resolution** by updating the TerraformersMC repository URL to
  the current releases endpoint (needed for newer Mod Menu artifacts).

## [0.2.0]

### Added
- **Aggressive Greedy (Absolute)** option in the config screen. Merges coplanar
  faces of the same block into the largest possible quads, ignoring the
  ambient-occlusion boundaries that normally cap merge size. Fewer quads at the
  cost of slightly coarser lighting on large flat surfaces. Off by default.
- **VulkanMod support for the 26.1.x line** (26.1, 26.1.1, 26.1.2), using
  VulkanMod 0.6.8. Greedy meshing now works under the VulkanMod renderer on the
  unobfuscated Minecraft line, alongside the existing Sodium and vanilla paths.
  Runtime-verified; still considered experimental.
- **Minecraft 26.2 support**, including Minecraft's own native experimental
  Vulkan rendering backend (distinct from the VulkanMod mod, which has no 26.2
  build yet). Vanilla/OpenGL and Sodium both verified working alongside it.

### Fixed
- **Fancy-grass mod compatibility** (BetterGrassify, LambdaBetterGrass, ArdaGrass).
  Grass-spread blocks (grass block, podzol, mycelium, crimson/warped nylium) are
  now excluded from greedy meshing when such a mod is installed, so their
  neighbour-based side textures render correctly. No effect when no such mod is
  present.
- **Mod icon not displaying in Mod Menu** (showed as a "?"). Replaced the
  oversized 1224×1224 icon with a standard 128×128 PNG.
- **Terrain shader failing to compile under 26.2's native Vulkan backend.** An
  unused vertex attribute in the shipped terrain shader passed silently under
  OpenGL but failed strict Vulkan pipeline validation; removed.
- **Chunk-build crash on Sodium 0.9.x (26.2).** An internal Sodium field our
  accessor mixin reads was renamed upstream; fixed the version-specific target.

### Changed
- Fabric Loader requirement bumped to 0.18.6 on the 26.1.x versions (required by
  VulkanMod 0.6.8); 26.2 requires Fabric Loader 0.19.3.

## [0.0.5]

- Multi-version support, lighting fixes, Sodium compatibility.
