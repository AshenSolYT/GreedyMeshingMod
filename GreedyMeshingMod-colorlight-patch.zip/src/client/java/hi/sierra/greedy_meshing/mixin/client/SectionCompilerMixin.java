package hi.sierra.greedy_meshing.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexSorting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
//? if UNOBFUSCATED {
/*import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.resources.model.geometry.BakedQuad;
*///?} else if >=1.21.5 {
/*import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BlockModelPart;
import net.minecraft.client.renderer.block.model.BlockStateModel;
*///?} else {
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.BakedModel;
//?}
// Greedy Water is not yet supported on the UNOBFUSCATED (26.x) branch (see
// GreedyEligibility.isGreedyWaterSource) — BlockRenderDispatcher's package and the fabric-api
// fluid-rendering module's jar-in-jar resolution both differ there and haven't been verified.
//? if UNOBFUSCATED {

//?} else {
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
//?}
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SectionBufferBuilderPack;
//? if >=1.21.6 {
/*import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
*///?} else {
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.chunk.RenderChunkRegion;
//?}
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.util.RandomSource;
//? if UNOBFUSCATED {
/*import net.minecraft.client.renderer.block.BlockAndTintGetter;
*///?} else {
import net.minecraft.world.level.BlockAndTintGetter;
//?}
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import hi.sierra.greedy_meshing.GreedyConfig;
import hi.sierra.greedy_meshing.GreedyEligibility;
import hi.sierra.greedy_meshing.GreedyMesher;
import hi.sierra.greedy_meshing.client.GreedyDebugStore;
import hi.sierra.greedy_meshing.client.GreedyEmissiveSupport;
import hi.sierra.greedy_meshing.client.GreedyLighting;
import hi.sierra.greedy_meshing.client.GreedyPerformanceStats;
import hi.sierra.greedy_meshing.client.GreedyRuntimeState;
import hi.sierra.greedy_meshing.client.GreedySpriteSupport;
import hi.sierra.greedy_meshing.client.GreedyVanillaWorkState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Map;

@Mixin(SectionCompiler.class)
public abstract class SectionCompilerMixin {
    //? if >=1.21.6 {
    /*@Shadow
    protected abstract BufferBuilder getOrBeginLayer(
            Map<ChunkSectionLayer, BufferBuilder> map,
            SectionBufferBuilderPack pack,
            ChunkSectionLayer layer
    );
    *///?} else {
    @Shadow
    protected abstract BufferBuilder getOrBeginLayer(
            Map<RenderType, BufferBuilder> map,
            SectionBufferBuilderPack pack,
            RenderType layer
    );
    //?}

    @Unique
    private static final ThreadLocal<GreedyVanillaWorkState> GREEDY_MESHING$STATE = ThreadLocal.withInitial(GreedyVanillaWorkState::new);
    @Unique
    private static final Direction[] GREEDY_MESHING$FACES = Direction.values();
    @Inject(method = "compile", at = @At("HEAD"))
    private void greedyMeshing$beginCompile(
            SectionPos sectionPos,
            //? if >=1.21.6 {
            /*RenderSectionRegion renderSectionRegion,
            *///?} else {
            RenderChunkRegion renderSectionRegion,
            //?}
            VertexSorting vertexSorting,
            SectionBufferBuilderPack sectionBufferBuilderPack,
            CallbackInfoReturnable<SectionCompiler.Results> cir
    ) {
        GreedyVanillaWorkState work = GREEDY_MESHING$STATE.get();
        work.reset(sectionPos);
        GreedyDebugStore.clearSection(sectionPos.asLong());
        // Zero the section's live contribution up front so a rebuild that merges nothing leaves no
        // stale geometry behind in the loaded-terrain totals.
        GreedyPerformanceStats.clearSectionGeometry(sectionPos.asLong());
        GreedyPerformanceStats.onVanillaCompileHook();
    }

    /**
     * Wraps getRenderShape() inside the block iteration loop of compile().
     * This works WITH Fabric Indigo's redirect — if Indigo is present, our wrapper
     * runs around Indigo's redirect. For greedy-eligible blocks, we store them and
     * return INVISIBLE to prevent both Indigo and vanilla from rendering them.
     */
    @WrapOperation(
            method = "compile",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getRenderShape()Lnet/minecraft/world/level/block/RenderShape;"
            )
    )
    private RenderShape greedyMeshing$wrapGetRenderShape(
            BlockState state,
            Operation<RenderShape> original,
            //? if >=1.21.6 {
            /*@Local(argsOnly = true) RenderSectionRegion region,
            *///?} else {
            @Local(argsOnly = true) RenderChunkRegion region,
            //?}
            @Local(ordinal = 2) BlockPos blockPos
    ) {
        GreedyVanillaWorkState work = GREEDY_MESHING$STATE.get();
        if (work.initialized() && work.greedyActive()) {
            int localX = blockPos.getX() - work.baseX();
            int localY = blockPos.getY() - work.baseY();
            int localZ = blockPos.getZ() - work.baseZ();
            if (localX >= 0 && localX < GreedyMesher.SECTION_SIZE
                    && localY >= 0 && localY < GreedyMesher.SECTION_SIZE
                    && localZ >= 0 && localZ < GreedyMesher.SECTION_SIZE
                    && GreedyEligibility.isGreedyOpaqueCube(state, region, blockPos)
                    && GreedySpriteSupport.supportsGreedySpriteSizes(state)) {
                int idx = GreedyMesher.index(localX, localY, localZ);
                work.addEligible(idx, state);
                return RenderShape.INVISIBLE;
            }
        }
        return original.call(state);
    }

    // Water's fluid quads are emitted through a code path entirely separate from the block-model
    // loop above — BlockState.getRenderShape() for water is INVISIBLE, so
    // greedyMeshing$wrapGetRenderShape never sees it. This redirects the fluid-render call itself.
    // Only plain still-water source blocks that pass GreedyEligibility.isGreedyWaterSource are
    // captured; everything else (flowing water, waterlogged blocks, lava, modded fluids) falls
    // through to vanilla's normal per-block rendering. Not yet wired up on the UNOBFUSCATED (26.x)
    // branch — see the import guard above and GreedyEligibility.isGreedyWaterSource, which always
    // returns false there, making this omission a no-op rather than a behavior change.
    //? if UNOBFUSCATED {
    
    //?} else {
    @Redirect(
            method = "compile",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/block/BlockRenderDispatcher;renderLiquid(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/BlockAndTintGetter;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/material/FluidState;)V"
            )
    )
    private void greedyMeshing$redirectRenderLiquid(
            BlockRenderDispatcher dispatcher,
            BlockPos pos,
            BlockAndTintGetter level,
            VertexConsumer output,
            BlockState state,
            FluidState fluidState
    ) {
        GreedyVanillaWorkState work = GREEDY_MESHING$STATE.get();
        if (work.initialized() && work.greedyActive()
                && GreedyEligibility.isGreedyWaterSource(state, level, pos)) {
            int localX = pos.getX() - work.baseX();
            int localY = pos.getY() - work.baseY();
            int localZ = pos.getZ() - work.baseZ();
            if (localX >= 0 && localX < GreedyMesher.SECTION_SIZE
                    && localY >= 0 && localY < GreedyMesher.SECTION_SIZE
                    && localZ >= 0 && localZ < GreedyMesher.SECTION_SIZE) {
                work.addEligible(GreedyMesher.index(localX, localY, localZ), state);
                return;
            }
        }
        dispatcher.renderLiquid(pos, level, output, state, fluidState);
    }
    //?}

    /**
     * Inject just before the map.entrySet() loop that builds MeshData from BufferBuilders.
     * At this point, Indigo/vanilla have rendered all non-greedy blocks into the buffers.
     * We add our greedy quads to the SOLID buffer before it gets built into MeshData.
     */
    @Inject(
            method = "compile",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/Map;entrySet()Ljava/util/Set;"
            )
    )
    private void greedyMeshing$emitGreedyQuads(
            SectionPos sectionPos,
            //? if >=1.21.6 {
            /*RenderSectionRegion renderSectionRegion,
            *///?} else {
            RenderChunkRegion renderSectionRegion,
            //?}
            VertexSorting vertexSorting,
            SectionBufferBuilderPack sectionBufferBuilderPack,
            CallbackInfoReturnable<SectionCompiler.Results> cir,
            //? if >=1.21.6 {
            /*@Local Map<ChunkSectionLayer, BufferBuilder> map
            *///?} else {
            @Local Map<RenderType, BufferBuilder> map
            //?}
    ) {
        GreedyVanillaWorkState work = GREEDY_MESHING$STATE.get();
        try {
            if (!work.greedyActive() || work.eligibleCount() <= 0) {
                return;
            }

            int baseX = work.baseX();
            int baseY = work.baseY();
            int baseZ = work.baseZ();
            work.scratchLighting.applyDirectionalShade =
                    !GreedyRuntimeState.isInSableSubLevel(baseX >> 4, baseZ >> 4);

            long[][] mergeKeys = work.faceMergeKeys();
            populateFaceVisibility(renderSectionRegion, work.sectionStates(), work.visibleFaces(), mergeKeys, baseX, baseY, baseZ, work.eligibleIndices(), work.eligibleCount());
            List<GreedyMesher.GreedyQuad> merged = GreedyMesher.meshWithKeys(
                    work.sectionStates(), work.visibleFaces(), mergeKeys
            );
            if (merged.isEmpty()) {
                return;
            }

            boolean captureDebug = GreedyConfig.debugWireframe() || GreedyConfig.debugTrianglesHud() || GreedyConfig.debugComparison();
            List<GreedyDebugStore.DebugQuad> debugQuads = captureDebug ? new ArrayList<>(merged.size()) : List.of();
            int emittedQuads = 0;
            int vanillaEquivalent = 0;
            boolean shaderPackActive = GreedyRuntimeState.isShaderPackActive();

            for (GreedyMesher.GreedyQuad quad : merged) {
                long cacheKey = ((long) quad.state().hashCode() << 32) | quad.face().ordinal();
                // Open-addressing cache lookup — avoids Long autoboxing and HashMap overhead
                int slot = (int)(cacheKey ^ (cacheKey >>> 32)) & (GreedyVanillaWorkState.LAYER_CACHE_SIZE - 1);
                @SuppressWarnings("unchecked")
                List<FaceAppearance> faceLayers;
                if (work.layerCacheKeys[slot] == cacheKey && work.layerCacheValues[slot] != null) {
                    faceLayers = (List<FaceAppearance>) work.layerCacheValues[slot];
                } else {
                    faceLayers = greedyMeshing$resolveFaceLayers(quad.state(), quad.face());
                    work.layerCacheKeys[slot] = cacheKey;
                    work.layerCacheValues[slot] = faceLayers;
                }
                int blockFaces = quad.width() * quad.height();
                for (FaceAppearance faceLayer : faceLayers) {
                    //? if UNOBFUSCATED {
                    /*BufferBuilder layerBuilder = getOrBeginLayer(map, sectionBufferBuilderPack, faceLayer.layer());
                    *///?} else {
                    // ItemBlockRenderTypes.getChunkRenderType(BlockState) looks the block up in a
                    // block->RenderType table that fluids are never registered in (they're keyed by
                    // Fluid via getRenderLayer(FluidState) instead) — water needs the fluid-specific
                    // overload or it silently resolves to the SOLID layer.
                    BufferBuilder layerBuilder = getOrBeginLayer(map, sectionBufferBuilderPack,
                            quad.state().is(Blocks.WATER)
                                    ? ItemBlockRenderTypes.getRenderLayer(quad.state().getFluidState())
                                    : ItemBlockRenderTypes.getChunkRenderType(quad.state()));
                    //?}
                    if (shaderPackActive || !GreedySpriteSupport.supportsMergedShaderSprite(faceLayer.sprite())) {
                        emittedQuads += emitTiledQuads(layerBuilder, quad,
                                faceLayer.sprite().getU0(), faceLayer.sprite().getU1(),
                                faceLayer.sprite().getV0(), faceLayer.sprite().getV1(),
                                faceLayer.tinted(), faceLayer.tintIndex(), renderSectionRegion, baseX, baseY, baseZ,
                                work, false);
                    } else {
                        emittedQuads += emitGreedyQuad(layerBuilder, quad,
                                faceLayer.sprite().getU0(), faceLayer.sprite().getU1(),
                                faceLayer.sprite().getV0(), faceLayer.sprite().getV1(),
                                faceLayer.tinted(), faceLayer.tintIndex(), renderSectionRegion, baseX, baseY, baseZ,
                                work, faceLayer.sprite().contents().width(), work.visibleFaces()[quad.face().ordinal()]);
                    }
                    TextureAtlasSprite emissive = GreedyEmissiveSupport.find(faceLayer.sprite());
                    if (emissive != null) {
                        // OptiFine-style _e textures use transparent pixels for the non-glowing
                        // parts.  Do not put them in the solid buffer: the solid shader forces
                        // alpha to one and turns the transparent background into enlarged dark
                        // pixels.  The cutout buffer preserves the emissive texture's alpha.
                        //? if >=1.21.6 {
                        /*BufferBuilder emissiveBuilder = getOrBeginLayer(map, sectionBufferBuilderPack, ChunkSectionLayer.CUTOUT);
                        *///?} else {
                        BufferBuilder emissiveBuilder = getOrBeginLayer(map, sectionBufferBuilderPack, RenderType.cutout());
                        //?}
                        emittedQuads += emitTiledQuads(emissiveBuilder, quad,
                                emissive.getU0(), emissive.getU1(), emissive.getV0(), emissive.getV1(),
                                false, -1, renderSectionRegion, baseX, baseY, baseZ, work, true);
                    }
                    vanillaEquivalent += blockFaces;
                }
                if (captureDebug) {
                    debugQuads.add(toDebugQuad(quad, baseX, baseY, baseZ, renderSectionRegion, work.scratchTintPos));
                }
            }

            GreedyPerformanceStats.onGreedySectionBuilt(work.eligibleCount(), merged.size(), emittedQuads, vanillaEquivalent);
            GreedyPerformanceStats.setSectionGeometry(sectionPos.asLong(), emittedQuads, vanillaEquivalent);
            if (captureDebug) {
                GreedyDebugStore.setSectionQuads(sectionPos.asLong(), debugQuads);
            }
        } finally {
            GREEDY_MESHING$STATE.remove();
        }
    }

    private static GreedyDebugStore.DebugQuad toDebugQuad(
            GreedyMesher.GreedyQuad quad, int baseX, int baseY, int baseZ,
            //? if >=1.21.6 {
            /*RenderSectionRegion region,
            *///?} else {
            RenderChunkRegion region,
            //?}
            BlockPos.MutableBlockPos scratch
    ) {
        float top = greedyMeshing$waterSurfaceTop(region, quad, baseX, baseY, baseZ, scratch);
        float[] c = corners(quad, top);
        return new GreedyDebugStore.DebugQuad(
                c[0] + baseX, c[1] + baseY, c[2] + baseZ,
                c[3] + baseX, c[4] + baseY, c[5] + baseZ,
                c[6] + baseX, c[7] + baseY, c[8] + baseZ,
                c[9] + baseX, c[10] + baseY, c[11] + baseZ
        );
    }

    /**
     * Returns ALL quad layers for a block face. Most blocks have 1 layer.
     * Blocks like grass have 2 layers on sides (dirt base + tinted overlay).
     * We emit one merged quad per layer, preserving overlays on merged faces.
     */
    @Unique
    private static List<FaceAppearance> greedyMeshing$resolveFaceLayers(BlockState state, Direction face) {
        if (state.is(Blocks.WATER)) {
            return greedyMeshing$resolveWaterFaceLayers(state);
        }
        //? if UNOBFUSCATED {
        /*BlockStateModel model = Minecraft.getInstance().getModelManager().getBlockStateModelSet().get(state);
        RandomSource random = RandomSource.create(0L);
        List<BlockStateModelPart> parts = new ArrayList<>();
        model.collectParts(random, parts);
        List<FaceAppearance> layers = new ArrayList<>();

        for (BlockStateModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(face)) {
                layers.add(new FaceAppearance(quad.materialInfo().sprite(), quad.materialInfo().isTinted(), quad.materialInfo().layer(), quad.materialInfo().tintIndex()));
            }
        }
        for (BlockStateModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(null)) {
                if (quad.direction() == face) {
                    layers.add(new FaceAppearance(quad.materialInfo().sprite(), quad.materialInfo().isTinted(), quad.materialInfo().layer(), quad.materialInfo().tintIndex()));
                }
            }
        }
        if (layers.isEmpty()) {
            layers.add(new FaceAppearance(model.particleMaterial().sprite(), false, ChunkSectionLayer.SOLID, -1));
        }
        *///?} else if >=1.21.5 {
        /*BlockStateModel model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
        RandomSource random = RandomSource.create(0L);
        List<BlockModelPart> parts = model.collectParts(random);
        List<FaceAppearance> layers = new ArrayList<>();

        for (BlockModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(face)) {
                layers.add(new FaceAppearance(quad.sprite(), quad.isTinted(), quad.tintIndex()));
            }
        }
        for (BlockModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(null)) {
                if (quad.direction() == face) {
                    layers.add(new FaceAppearance(quad.sprite(), quad.isTinted(), quad.tintIndex()));
                }
            }
        }
        if (layers.isEmpty()) {
            layers.add(new FaceAppearance(model.particleIcon(), false, -1));
        }
        *///?} else {
        BakedModel model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
        RandomSource random = RandomSource.create(0L);
        List<FaceAppearance> layers = new ArrayList<>();

        for (BakedQuad quad : model.getQuads(state, face, random)) {
            layers.add(new FaceAppearance(quad.getSprite(), quad.isTinted(), quad.getTintIndex()));
        }
        for (BakedQuad quad : model.getQuads(state, null, random)) {
            if (quad.getDirection() == face) {
                layers.add(new FaceAppearance(quad.getSprite(), quad.isTinted(), quad.getTintIndex()));
            }
        }
        if (layers.isEmpty()) {
            layers.add(new FaceAppearance(model.getParticleIcon(), false, -1));
        }
        //?}
        return layers;
    }

    /**
     * Water's BlockState.getRenderShape() is INVISIBLE, so it has no real baked model — the
     * generic greedyMeshing$resolveFaceLayers path above (which looks up a baked model) doesn't
     * apply. Resolve the still-water sprite via Fabric's fluid-rendering API instead; the world
     * position doesn't matter here (Fabric's default water handler ignores it when picking the
     * sprite), only the FluidState, so this is safe to cache per-BlockState like the opaque path.
     */
    @Unique
    private static List<FaceAppearance> greedyMeshing$resolveWaterFaceLayers(BlockState state) {
        //? if UNOBFUSCATED {
        /*// Not yet wired up on this branch — see GreedyEligibility.isGreedyWaterSource, which
        // always returns false here, so this is unreachable rather than a behavior change.
        return List.of();
        *///?} else {
        // Fabric API registers a default handler for vanilla water unconditionally on init, so this
        // is never actually null in practice — GreedyEligibility.isGreedyWaterSource already gates
        // out anything that isn't plain Blocks.WATER before this is ever called.
        FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(Fluids.WATER);
        if (handler == null) {
            return List.of();
        }
        TextureAtlasSprite sprite = handler.getFluidSprites(null, null, state.getFluidState())[0];
        return List.of(new FaceAppearance(sprite, true, -1));
        //?}
    }

    @Unique
    private static void populateFaceVisibility(
            //? if >=1.21.6 {
            /*RenderSectionRegion region,
            *///?} else {
            RenderChunkRegion region,
            //?}
            BlockState[] sectionStates,
            BitSet[] visibleFaces,
            long[][] faceMergeKeys,
            int baseX,
            int baseY,
            int baseZ,
            int[] eligibleIndices,
            int eligibleCount
    ) {
        GreedyMesher.clearFaceMaskArray(visibleFaces);
        BlockPos.MutableBlockPos samplePos = new BlockPos.MutableBlockPos();
        for (int i = 0; i < eligibleCount; i++) {
            int idx = eligibleIndices[i];
            BlockState state = sectionStates[idx];
            if (state == null) {
                continue;
            }

            int x = idx & 15;
            int y = (idx >> 8) & 15;
            int z = (idx >> 4) & 15;
            int worldX = baseX + x;
            int worldY = baseY + y;
            int worldZ = baseZ + z;
            for (Direction face : GREEDY_MESHING$FACES) {
                int nx = x + face.getStepX();
                int ny = y + face.getStepY();
                int nz = z + face.getStepZ();
                if (nx >= 0 && nx < GreedyMesher.SECTION_SIZE
                        && ny >= 0 && ny < GreedyMesher.SECTION_SIZE
                        && nz >= 0 && nz < GreedyMesher.SECTION_SIZE
                        && sectionStates[GreedyMesher.index(nx, ny, nz)] != null) {
                    continue;
                }

                samplePos.set(worldX + face.getStepX(), worldY + face.getStepY(), worldZ + face.getStepZ());
                BlockState neighbor = region.getBlockState(samplePos);
                //? if >=1.21.2 {
                if (Block.shouldRenderFace(state, neighbor, face)) {
                //?} else {
                /*if (Block.shouldRenderFace(state, region, new BlockPos(worldX, worldY, worldZ), face, samplePos)) {
                *///?}
                    visibleFaces[face.ordinal()].set(idx);
                    int mergeKey;
                    if (state.is(Blocks.WATER)) {
                        // Water only merges within the interior of a flat, uncovered still-water body
                        // (see GreedyEligibility.isGreedyWaterSource + isFlatWaterSurface) — vanilla
                        // renders a sloped, per-corner-averaged surface everywhere else, which this
                        // mod's flat GreedyQuad rectangles can't represent. The bottom face is always
                        // an exact flat square regardless of the top surface's slope, so it skips the
                        // check; every other face (including the sides, whose top edge follows the
                        // same slope as the top face) needs it. Non-flat faces get a unique key so they
                        // fall back to individual 1x1 quads — pixel-identical to un-merged vanilla
                        // rendering, never a regression.
                        boolean flat = face == Direction.DOWN
                                || isFlatWaterSurface(region, worldX, worldY, worldZ, samplePos);
                        mergeKey = flat ? 0 : (0x40000000 | idx);
                    } else {
                        // Aggressive ("absolute") greedy ignores the AO signature so same-block faces
                        // merge into the largest possible quads; lighting is still sampled per sub-quad.
                        mergeKey = GreedyConfig.aggressiveGreedy()
                                ? 0
                                : computeAoKey(region, samplePos, worldX, worldY, worldZ, face);
                    }
                    faceMergeKeys[face.ordinal()][idx] = mergeKey;
                }
            }
        }
    }

    /**
     * True iff the 3x3 horizontal neighbourhood centered on (worldX, worldY, worldZ) is entirely
     * uncovered still-water source blocks — the union of the four lattice corners vanilla's own
     * per-corner height averaging touches for this block's top face. Checking the superset rather
     * than each corner's exact 2x2 footprint is conservative: a handful of tiles that would actually
     * render flat get misclassified as non-flat (and simply don't merge), which is acceptable —
     * this check only ever removes merge opportunities, never approves an incorrect one.
     */
    @Unique
    private static boolean isFlatWaterSurface(
            //? if >=1.21.6 {
            /*RenderSectionRegion region,
            *///?} else {
            RenderChunkRegion region,
            //?}
            int worldX, int worldY, int worldZ, BlockPos.MutableBlockPos scratch
    ) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                scratch.set(worldX + dx, worldY, worldZ + dz);
                BlockState neighborState = region.getBlockState(scratch);
                if (!neighborState.is(Blocks.WATER)) {
                    return false;
                }
                FluidState neighborFluid = neighborState.getFluidState();
                if (!neighborFluid.isSource() || neighborFluid.getType() != Fluids.WATER) {
                    return false;
                }
                scratch.set(worldX + dx, worldY + 1, worldZ + dz);
                if (region.getBlockState(scratch).getFluidState().getType() == Fluids.WATER) {
                    return false;
                }
            }
        }
        return true;
    }

    @Unique
    private static final int[][][] AO_OFFSETS = new int[6][8][3];
    static {
        Direction[] faces = Direction.values();
        for (Direction face : faces) {
            int ax1, ay1, az1, ax2, ay2, az2;
            switch (face) {
                case DOWN, UP     -> { ax1=1; ay1=0; az1=0; ax2=0; ay2=0; az2=1; }
                case NORTH, SOUTH -> { ax1=1; ay1=0; az1=0; ax2=0; ay2=1; az2=0; }
                default           -> { ax1=0; ay1=0; az1=1; ax2=0; ay2=1; az2=0; }
            }
            int idx = 0;
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    AO_OFFSETS[face.ordinal()][idx][0] = face.getStepX() + a * ax1 + b * ax2;
                    AO_OFFSETS[face.ordinal()][idx][1] = face.getStepY() + a * ay1 + b * ay2;
                    AO_OFFSETS[face.ordinal()][idx][2] = face.getStepZ() + a * az1 + b * az2;
                    idx++;
                }
            }
        }
    }

    @Unique
    //? if >=1.21.6 {
    /*private static int computeAoKey(RenderSectionRegion region, BlockPos.MutableBlockPos pos,
    *///?} else {
    private static int computeAoKey(RenderChunkRegion region, BlockPos.MutableBlockPos pos,
    //?}
                                     int worldX, int worldY, int worldZ, Direction face) {
        int[][] offsets = AO_OFFSETS[face.ordinal()];
        int key = 0;
        for (int i = 0; i < 8; i++) {
            pos.set(worldX + offsets[i][0], worldY + offsets[i][1], worldZ + offsets[i][2]);
            BlockState neighbor = region.getBlockState(pos);
            //? if >=26.3 {
            /*// 26.3 narrowed isViewBlocking to the camera near-plane check; vanilla and Sodium AO
            // now test isLightPermeable(), which is the same solid-and-dampening predicate.
            if (!neighbor.isLightPermeable()) {
            *///?} else {
            if (neighbor.isViewBlocking(region, pos)
                    //? if UNOBFUSCATED {
                    /*&& neighbor.getLightDampening() != 0
                    *///?} else if >=1.21.2 {
                    && neighbor.getLightBlock() != 0
                    //?} else {
                    /*&& neighbor.getLightBlock(region, pos) != 0
                    *///?}
            ) {
            //?}
                key |= (1 << i);
            }
        }
        // AO occupancy alone is insufficient: two otherwise identical faces can sit on
        // opposite sides of a block/sky-light boundary. Keep the four-bit block and sky
        // levels in disjoint key bits so a dark sample cannot be interpolated across a
        // brighter merged run. Aggressive mode deliberately bypasses this whole key.
        pos.set(worldX + face.getStepX(), worldY + face.getStepY(), worldZ + face.getStepZ());
        int packedLight = GreedyLighting.mergeLightKey(region, pos);
        key |= ((packedLight >>> 4) & 0xF) << 8;
        key |= ((packedLight >>> 20) & 0xF) << 12;
        return key;
    }

    /** Max sub-quad size for lighting subdivision. Larger merged quads are split into
     *  sub-quads of at most this size so lighting gets sampled every LIGHT_STEP blocks. */
    private static final int LIGHT_STEP = 4;

    private static int emitGreedyQuad(
            VertexConsumer consumer, GreedyMesher.GreedyQuad quad,
            float u0, float u1, float v0, float v1,
            //? if >=1.21.6 {
            /*boolean applyTint, int tintIndex, RenderSectionRegion region,
            *///?} else {
            boolean applyTint, int tintIndex, RenderChunkRegion region,
            //?}
            int baseX, int baseY, int baseZ,
            GreedyVanillaWorkState work,
            int spriteSize,
            BitSet visible
    ) {
        int W = quad.width();
        int H = quad.height();

        // Single-block: emit directly with full AO
        if (W == 1 && H == 1) {
                emitSubQuad(consumer, quad, 0, 0, 1, 1, W, H, u0, u1, v0, v1,
                    applyTint, tintIndex, region, baseX, baseY, baseZ, work, true, spriteSize, 0);
            return 1;
        }

        // Which of the quad's 4 outer edges actually border more visible same-direction geometry
        // (a real T-junction with a separately-meshed quad) vs. a true silhouette/corner, computed
        // once for the whole merged quad rather than per sub-quad.
        int skirtMask = greedyMeshing$computeSkirtMask(visible, quad.face(), quad.x(), quad.y(), quad.z(), W, H);

        // Subdivide into LIGHT_STEP x LIGHT_STEP sub-quads for better lighting
        int count = 0;
        for (int sv = 0; sv < H; sv += LIGHT_STEP) {
            int sh = Math.min(LIGHT_STEP, H - sv);
            for (int su = 0; su < W; su += LIGHT_STEP) {
                int sw = Math.min(LIGHT_STEP, W - su);
                emitSubQuad(consumer, quad, su, sv, sw, sh, W, H, u0, u1, v0, v1,
                        applyTint, tintIndex, region, baseX, baseY, baseZ, work, false, spriteSize, skirtMask);
                count++;
            }
        }
        return count;
    }

    /**
     * Bitmask (1=uMin, 2=uMax, 4=vMin, 8=vMax) of which outer edges of a merged quad are safe to
     * crack-skirt: either the true edge of the 16-block section (the original cross-section T-junction
     * case this fix targets), or an edge that actually borders more visible same-direction geometry
     * (a real seam between two separately-meshed quads). An edge with neither is a genuine silhouette
     * — e.g. a block corner where a perpendicular face meets — and nudging it outward there pushes the
     * quad past the true geometric boundary into that other face's space instead of closing a gap.
     */
    @Unique
    private static int greedyMeshing$computeSkirtMask(BitSet visible, Direction face, int qx, int qy, int qz, int w, int h) {
        int uStart, vStart;
        switch (face) {
            case NORTH, SOUTH -> { uStart = qx; vStart = qy; }
            case WEST, EAST   -> { uStart = qz; vStart = qy; }
            default           -> { uStart = qx; vStart = qz; } // DOWN, UP
        }
        int mask = 0;
        if (uStart == 0 || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, -1, 0)) mask |= 1;
        if (uStart + w == GreedyMesher.SECTION_SIZE || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, 1, 0)) mask |= 2;
        if (vStart == 0 || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, 0, -1)) mask |= 4;
        if (vStart + h == GreedyMesher.SECTION_SIZE || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, 0, 1)) mask |= 8;
        return mask;
    }

    @Unique
    private static boolean greedyMeshing$edgeHasNeighbor(BitSet visible, Direction face, int qx, int qy, int qz, int w, int h, int du, int dv) {
        if (du != 0) {
            int u = du < 0 ? -1 : w;
            for (int v = 0; v < h; v++) {
                if (greedyMeshing$cellVisible(visible, face, qx, qy, qz, u, v)) return true;
            }
        } else {
            int v = dv < 0 ? -1 : h;
            for (int u = 0; u < w; u++) {
                if (greedyMeshing$cellVisible(visible, face, qx, qy, qz, u, v)) return true;
            }
        }
        return false;
    }

    @Unique
    private static boolean greedyMeshing$cellVisible(BitSet visible, Direction face, int qx, int qy, int qz, int u, int v) {
        int x, y, z;
        switch (face) {
            case NORTH, SOUTH -> { x = qx + u; y = qy + v; z = qz; }
            case WEST, EAST   -> { x = qx; y = qy + v; z = qz + u; }
            default           -> { x = qx + u; y = qy; z = qz + v; } // DOWN, UP
        }
        if (x < 0 || x >= GreedyMesher.SECTION_SIZE || y < 0 || y >= GreedyMesher.SECTION_SIZE || z < 0 || z >= GreedyMesher.SECTION_SIZE) {
            return false;
        }
        return visible.get(GreedyMesher.index(x, y, z));
    }

    /** World-space overlap nudged onto a merged quad's outer edge to hide sub-pixel raster
     *  gaps ("T-junction cracks") some GPU drivers leave between it and neighboring quads that
     *  were meshed independently. Small enough to be visually imperceptible. */
    @Unique
    private static final float CRACK_SKIRT = 1f / 128f;

    @Unique
    private static void emitSubQuad(
            VertexConsumer consumer, GreedyMesher.GreedyQuad quad,
            int offU, int offV, int subW, int subH, int fullW, int fullH,
            float u0, float u1, float v0, float v1,
            //? if >=1.21.6 {
            /*boolean applyTint, int tintIndex, RenderSectionRegion region,
            *///?} else {
            boolean applyTint, int tintIndex, RenderChunkRegion region,
            //?}
            int baseX, int baseY, int baseZ,
            GreedyVanillaWorkState work,
            boolean fullAO,
            int spriteSize,
            int skirtMask
    ) {
        // Build a temporary sub-quad with offset position and sub-dimensions
        Direction face = quad.face();
        int qx = quad.x(), qy = quad.y(), qz = quad.z();

        // Offset the origin based on face direction's U/V axes
        int sx, sy, sz;
        switch (face) {
            case NORTH, SOUTH -> { sx = qx + offU; sy = qy + offV; sz = qz; }
            case WEST, EAST   -> { sx = qx; sy = qy + offV; sz = qz + offU; }
            case DOWN, UP     -> { sx = qx + offU; sy = qy; sz = qz + offV; }
            default -> { sx = qx; sy = qy; sz = qz; }
        }

        GreedyMesher.GreedyQuad sub = new GreedyMesher.GreedyQuad(face, sx, sy, sz, subW, subH, quad.state());

        float[] c = work.scratchCorners;
        float top = greedyMeshing$waterSurfaceTop(region, sub, baseX, baseY, baseZ, work.scratchTintPos);
        fillCorners(c, sub, top);
        if (!fullAO && GreedyRuntimeState.requiresCrackSafeSubdivision()) {
            skirtCorners(c, face,
                    offU == 0 && (skirtMask & 1) != 0,
                    offU + subW == fullW && (skirtMask & 2) != 0,
                    offV == 0 && (skirtMask & 4) != 0,
                    offV + subH == fullH && (skirtMask & 8) != 0);
        }
        float faceAlpha = GreedySpriteSupport.mergedFaceAlpha(face, spriteSize);
        float nx = face.getStepX(), ny = face.getStepY(), nz = face.getStepZ();

        BlockColors blockColors = applyTint ? Minecraft.getInstance().getBlockColors() : null;
        BlockPos.MutableBlockPos tintPos = work.scratchTintPos;
        GreedyLighting.Scratch lighting = work.scratchLighting;

        float[] brightness = work.scratchBrightness;
        int[] lightmap = work.scratchLightmap;
        float[] tintR = work.scratchTintR;
        float[] tintG = work.scratchTintG;
        float[] tintB = work.scratchTintB;

        int[][] cornerBlocks = work.scratchCornerBlocks;
        greedyMeshing$fillCornerBlockPositions(cornerBlocks, sub, baseX, baseY, baseZ);

        for (int i = 0; i < 4; i++) {
            int wx = cornerBlocks[i][0];
            int wy = cornerBlocks[i][1];
            int wz = cornerBlocks[i][2];
            GreedyLighting.computeTileLighting(region, quad.state(), face, wx, wy, wz, lighting);
            brightness[i] = lighting.brightness[i];
            lightmap[i] = lighting.lightmap[i];

            int tint = applyTint ? tintColorForTile(quad.state(), region, wx, wy, wz, tintPos, blockColors, tintIndex) : 0xFFFFFF;
            tintR[i] = ((tint >> 16) & 0xFF) / 255.0f;
            tintG[i] = ((tint >> 8) & 0xFF) / 255.0f;
            tintB[i] = (tint & 0xFF) / 255.0f;
        }

        float cu = (u0 + u1) * 0.5f;
        float cv = (v0 + v1) * 0.5f;

        int a = (int) (faceAlpha * 255.0f) << 24;
        for (int vi = 0; vi < 4; vi++) {
            int ci = vi * 3;
            float br = brightness[vi];
            int packedColor = a
                    | ((int) (br * tintR[vi] * 255.0f) << 16)
                    | ((int) (br * tintG[vi] * 255.0f) << 8)
                    | (int) (br * tintB[vi] * 255.0f);
            consumer.addVertex(c[ci], c[ci + 1], c[ci + 2], packedColor, cu, cv, 0, lightmap[vi], nx, ny, nz);
        }
    }

    /**
     * Shader-pack fallback: emits one quad per block tile within the merged area.
     * Each tile gets correct per-block UVs and lighting, so external shaders
     * render them properly without needing custom UV tiling logic.
     * Still benefits from face culling (hidden internal faces already removed).
     */
    @Unique
    private static int emitTiledQuads(
            VertexConsumer consumer, GreedyMesher.GreedyQuad quad,
            float u0, float u1, float v0, float v1,
            //? if >=1.21.6 {
            /*boolean applyTint, int tintIndex, RenderSectionRegion region,
            *///?} else {
            boolean applyTint, int tintIndex, RenderChunkRegion region,
            //?}
            int baseX, int baseY, int baseZ,
            GreedyVanillaWorkState work,
            boolean fullbright
    ) {
        float nx = quad.face().getStepX(), ny = quad.face().getStepY(), nz = quad.face().getStepZ();
        boolean flipV = quad.face().getAxis().isHorizontal();
        float tv0 = flipV ? v1 : v0, tv1 = flipV ? v0 : v1;

        BlockColors blockColors = applyTint ? Minecraft.getInstance().getBlockColors() : null;
        BlockPos.MutableBlockPos tintPos = work.scratchTintPos;
        GreedyLighting.Scratch lighting = work.scratchLighting;

        int W = quad.width();
        int H = quad.height();
        float[] c = work.scratchCorners;
        float top = greedyMeshing$waterSurfaceTop(region, quad, baseX, baseY, baseZ, tintPos);
        fillCorners(c, quad, top);
        int count = 0;

        for (int tv = 0; tv < H; tv++) {
            for (int tu = 0; tu < W; tu++) {
                float fu0 = (float) tu / W, fu1 = (float) (tu + 1) / W;
                float fv0 = (float) tv / H, fv1 = (float) (tv + 1) / H;

                float x00 = greedyMeshing$interpolate(c, fu0, fv0, 0), y00 = greedyMeshing$interpolate(c, fu0, fv0, 1), z00 = greedyMeshing$interpolate(c, fu0, fv0, 2);
                float x10 = greedyMeshing$interpolate(c, fu1, fv0, 0), y10 = greedyMeshing$interpolate(c, fu1, fv0, 1), z10 = greedyMeshing$interpolate(c, fu1, fv0, 2);
                float x11 = greedyMeshing$interpolate(c, fu1, fv1, 0), y11 = greedyMeshing$interpolate(c, fu1, fv1, 1), z11 = greedyMeshing$interpolate(c, fu1, fv1, 2);
                float x01 = greedyMeshing$interpolate(c, fu0, fv1, 0), y01 = greedyMeshing$interpolate(c, fu0, fv1, 1), z01 = greedyMeshing$interpolate(c, fu0, fv1, 2);

                int wx = baseX + (int) Math.floor(greedyMeshing$interpolate(c, fu0 + 0.001f, fv0 + 0.001f, 0));
                int wy = baseY + (int) Math.floor(greedyMeshing$interpolate(c, fu0 + 0.001f, fv0 + 0.001f, 1));
                int wz = baseZ + (int) Math.floor(greedyMeshing$interpolate(c, fu0 + 0.001f, fv0 + 0.001f, 2));

                if (fullbright) {
                    java.util.Arrays.fill(lighting.brightness, 1.0f);
                    java.util.Arrays.fill(lighting.lightmap, 0xF000F0);
                } else {
                    GreedyLighting.computeTileLighting(region, quad.state(), quad.face(), wx, wy, wz, lighting);
                }

                int tint = applyTint ? tintColorForTile(quad.state(), region, wx, wy, wz, tintPos, blockColors, tintIndex) : 0xFFFFFF;
                float tintR = ((tint >> 16) & 0xFF) / 255.0f;
                float tintG = ((tint >> 8) & 0xFF) / 255.0f;
                float tintB = (tint & 0xFF) / 255.0f;

                for (int vi = 0; vi < 4; vi++) {
                    float br = lighting.brightness[vi];
                    int packedColor = 0xFF000000
                            | ((int) (br * tintR * 255.0f) << 16)
                            | ((int) (br * tintG * 255.0f) << 8)
                            | (int) (br * tintB * 255.0f);
                    float px, py, pz, pu, pv;
                    switch (vi) {
                        case 0 -> { px = x00; py = y00; pz = z00; pu = u0; pv = tv0; }
                        case 1 -> { px = x10; py = y10; pz = z10; pu = u1; pv = tv0; }
                        case 2 -> { px = x11; py = y11; pz = z11; pu = u1; pv = tv1; }
                        default -> { px = x01; py = y01; pz = z01; pu = u0; pv = tv1; }
                    }
                    if (fullbright) {
                        // A larger separation prevents the emissive companion from depth-fighting
                        // the base face when the ore is viewed at long distance.
                        px += nx * 0.05f;
                        py += ny * 0.05f;
                        pz += nz * 0.05f;
                    }
                    consumer.addVertex(px, py, pz, packedColor, pu, pv, 0, lighting.lightmap[vi], nx, ny, nz);
                }
                count++;
            }
        }
        return count;
    }

    @Unique
    private static float greedyMeshing$interpolate(float[] c, float fu, float fv, int axis) {
        float bottom = c[0 + axis] + (c[3 + axis] - c[0 + axis]) * fu;
        float top    = c[9 + axis] + (c[6 + axis] - c[9 + axis]) * fu;
        return bottom + (top - bottom) * fv;
    }

    @Unique
    private static void greedyMeshing$fillCornerBlockPositions(int[][] out, GreedyMesher.GreedyQuad quad, int baseX, int baseY, int baseZ) {
        int x = baseX + quad.x();
        int y = baseY + quad.y();
        int z = baseZ + quad.z();
        int w = quad.width();
        int h = quad.height();
        switch (quad.face()) {
            case NORTH -> { out[0][0]=x+w-1; out[0][1]=y; out[0][2]=z; out[1][0]=x; out[1][1]=y; out[1][2]=z; out[2][0]=x; out[2][1]=y+h-1; out[2][2]=z; out[3][0]=x+w-1; out[3][1]=y+h-1; out[3][2]=z; }
            case SOUTH -> { out[0][0]=x; out[0][1]=y; out[0][2]=z; out[1][0]=x+w-1; out[1][1]=y; out[1][2]=z; out[2][0]=x+w-1; out[2][1]=y+h-1; out[2][2]=z; out[3][0]=x; out[3][1]=y+h-1; out[3][2]=z; }
            case WEST -> { out[0][0]=x; out[0][1]=y; out[0][2]=z; out[1][0]=x; out[1][1]=y; out[1][2]=z+w-1; out[2][0]=x; out[2][1]=y+h-1; out[2][2]=z+w-1; out[3][0]=x; out[3][1]=y+h-1; out[3][2]=z; }
            case EAST -> { out[0][0]=x; out[0][1]=y; out[0][2]=z+w-1; out[1][0]=x; out[1][1]=y; out[1][2]=z; out[2][0]=x; out[2][1]=y+h-1; out[2][2]=z; out[3][0]=x; out[3][1]=y+h-1; out[3][2]=z+w-1; }
            case DOWN -> { out[0][0]=x; out[0][1]=y; out[0][2]=z; out[1][0]=x+w-1; out[1][1]=y; out[1][2]=z; out[2][0]=x+w-1; out[2][1]=y; out[2][2]=z+h-1; out[3][0]=x; out[3][1]=y; out[3][2]=z+h-1; }
            case UP -> { out[0][0]=x; out[0][1]=y; out[0][2]=z+h-1; out[1][0]=x+w-1; out[1][1]=y; out[1][2]=z+h-1; out[2][0]=x+w-1; out[2][1]=y; out[2][2]=z; out[3][0]=x; out[3][1]=y; out[3][2]=z; }
        }
    }

    private static int tintColorForTile(
            BlockState state, BlockAndTintGetter region,
            int worldX, int worldY, int worldZ,
            BlockPos.MutableBlockPos samplePos, BlockColors blockColors, int tintIndex
    ) {
        samplePos.set(worldX, worldY, worldZ);
        if (state.is(Blocks.WATER)) {
            //? if UNOBFUSCATED {
            /*// Not yet wired up on this branch — see GreedyEligibility.isGreedyWaterSource, which
            // always returns false here, so this is unreachable rather than a behavior change.
            return 0xFFFFFF;
            *///?} else {
            // Water's biome tint is applied by the fluid renderer directly (BiomeColors.getAverageWaterColor),
            // not through the generic BlockColors registry the rest of this method uses.
            FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(Fluids.WATER);
            return handler != null ? handler.getFluidColor(region, samplePos, state.getFluidState()) : 0xFFFFFF;
            //?}
        }
        //? if UNOBFUSCATED {
        /*// A model can carry a tintindex the block has no tint source for (resource-pack models,
        // issue #21); the legacy getColor path reports that as -1, so treat null the same way.
        var tintSource = blockColors.getTintSource(state, tintIndex);
        int tint = tintSource == null ? -1 : tintSource.colorInWorld(state, region, samplePos);
        *///?} else {
        int tint = blockColors.getColor(state, region, samplePos, tintIndex);
        //?}
        return tint == -1 ? 0xFFFFFF : tint;
    }

    /**
     * The height of a water quad's top edge: a full block (1.0) for every non-water quad AND for
     * water that has more water directly above it (an internal boundary, not a real surface — vanilla
     * renders these at full height too, see LiquidBlockRenderer.getHeight's "covered" branch). Only a
     * water block genuinely exposed to something other than water above uses its own (usually ~0.889)
     * exposed-surface height. Must be checked per quad, NOT inferred from `state.is(Blocks.WATER)`
     * alone — a submerged water block still has BlockState water/LEVEL=0 like a surface block, so
     * blindly shrinking every water quad left a ~0.11-block gap at every internal layer boundary in
     * water deeper than 1 block (issue: merged water quads left gaps in multi-layer-deep water).
     */
    @Unique
    private static float greedyMeshing$waterSurfaceTop(
            //? if >=1.21.6 {
            /*RenderSectionRegion region,
            *///?} else {
            RenderChunkRegion region,
            //?}
            GreedyMesher.GreedyQuad quad, int baseX, int baseY, int baseZ, BlockPos.MutableBlockPos scratch
    ) {
        if (!quad.state().is(Blocks.WATER)) {
            return 1.0f;
        }
        scratch.set(baseX + quad.x(), baseY + quad.y() + 1, baseZ + quad.z());
        if (region.getBlockState(scratch).getFluidState().getType() == Fluids.WATER) {
            return 1.0f;
        }
        return quad.state().getFluidState().getOwnHeight();
    }

    private static float[] corners(GreedyMesher.GreedyQuad quad, float top) {
        float[] out = new float[12];
        fillCorners(out, quad, top);
        return out;
    }

    private static void fillCorners(float[] out, GreedyMesher.GreedyQuad quad, float top) {
        float x0 = quad.x(), y0 = quad.y(), z0 = quad.z();
        switch (quad.face()) {
            case NORTH -> { float x1 = x0 + quad.width(), y1 = y0 + quad.height() - 1 + top; out[0]=x1; out[1]=y0; out[2]=z0; out[3]=x0; out[4]=y0; out[5]=z0; out[6]=x0; out[7]=y1; out[8]=z0; out[9]=x1; out[10]=y1; out[11]=z0; }
            case SOUTH -> { float x1 = x0 + quad.width(), y1 = y0 + quad.height() - 1 + top, z1 = z0 + 1; out[0]=x0; out[1]=y0; out[2]=z1; out[3]=x1; out[4]=y0; out[5]=z1; out[6]=x1; out[7]=y1; out[8]=z1; out[9]=x0; out[10]=y1; out[11]=z1; }
            case WEST -> { float y1 = y0 + quad.height() - 1 + top, z1 = z0 + quad.width(); out[0]=x0; out[1]=y0; out[2]=z0; out[3]=x0; out[4]=y0; out[5]=z1; out[6]=x0; out[7]=y1; out[8]=z1; out[9]=x0; out[10]=y1; out[11]=z0; }
            case EAST -> { float x1 = x0 + 1, y1 = y0 + quad.height() - 1 + top, z1 = z0 + quad.width(); out[0]=x1; out[1]=y0; out[2]=z1; out[3]=x1; out[4]=y0; out[5]=z0; out[6]=x1; out[7]=y1; out[8]=z0; out[9]=x1; out[10]=y1; out[11]=z1; }
            case DOWN -> { float x1 = x0 + quad.width(), z1 = z0 + quad.height(); out[0]=x0; out[1]=y0; out[2]=z0; out[3]=x1; out[4]=y0; out[5]=z0; out[6]=x1; out[7]=y0; out[8]=z1; out[9]=x0; out[10]=y0; out[11]=z1; }
            case UP -> { float x1 = x0 + quad.width(), y1 = y0 + top, z1 = z0 + quad.height(); out[0]=x0; out[1]=y1; out[2]=z1; out[3]=x1; out[4]=y1; out[5]=z1; out[6]=x1; out[7]=y1; out[8]=z0; out[9]=x0; out[10]=y1; out[11]=z0; }
        }
    }

    // (uSide, vSide) per corner index, matching the fillCorners winding above: +1 means the
    // corner sits on that axis's max edge, -1 its min edge. Indexed by Direction.ordinal()
    // (DOWN, UP, NORTH, SOUTH, WEST, EAST).
    @Unique
    private static final int[][] CORNER_UV_SIDES = {
            { -1, -1,  1, -1,  1,  1, -1,  1 }, // DOWN
            { -1,  1,  1,  1,  1, -1, -1, -1 }, // UP
            {  1, -1, -1, -1, -1,  1,  1,  1 }, // NORTH
            { -1, -1,  1, -1,  1,  1, -1,  1 }, // SOUTH
            { -1, -1,  1, -1,  1,  1, -1,  1 }, // WEST
            {  1, -1, -1, -1, -1,  1,  1,  1 }, // EAST
    };

    /** Nudges a merged quad's outer-boundary corners outward by {@link #CRACK_SKIRT} so it
     *  slightly overlaps neighboring quads meshed independently, hiding raster gaps at the
     *  shared edge without adding geometry. Only touches corners on the {@code quad}'s true
     *  outer edge — internal lighting-subdivision cuts are left untouched. */
    @Unique
    private static void skirtCorners(float[] c, Direction face, boolean atUMin, boolean atUMax, boolean atVMin, boolean atVMax) {
        if (!atUMin && !atUMax && !atVMin && !atVMax) {
            return;
        }
        int axisU = (face == Direction.WEST || face == Direction.EAST) ? 2 : 0;
        int axisV = (face == Direction.DOWN || face == Direction.UP) ? 2 : 1;
        int[] sides = CORNER_UV_SIDES[face.ordinal()];
        for (int i = 0; i < 4; i++) {
            int uSide = sides[i * 2];
            int vSide = sides[i * 2 + 1];
            int ci = i * 3;
            if ((uSide < 0 && atUMin) || (uSide > 0 && atUMax)) {
                c[ci + axisU] += uSide * CRACK_SKIRT;
            }
            if ((vSide < 0 && atVMin) || (vSide > 0 && atVMax)) {
                c[ci + axisV] += vSide * CRACK_SKIRT;
            }
        }
    }

    //? if UNOBFUSCATED {
    /*private record FaceAppearance(TextureAtlasSprite sprite, boolean tinted, ChunkSectionLayer layer, int tintIndex) {}
    *///?} else {
    private record FaceAppearance(TextureAtlasSprite sprite, boolean tinted, int tintIndex) {}
    //?}

    // GreedyVanillaWorkState moved to hi.sierra.greedy_meshing.client package
    // to avoid mixin inner class loading restrictions
}
