    package hi.sierra.greedy_meshing.mixin.client.sodium;

//? if SODIUM {
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildBuffers;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildContext;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.buffers.ChunkModelBuilder;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.BlockRenderCache;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.BlockRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.FluidRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.tasks.ChunkBuilderMeshingTask;
import net.caffeinemc.mods.sodium.client.render.chunk.RenderSection;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.DefaultMaterials;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.TranslucentGeometryCollector;
import net.caffeinemc.mods.sodium.client.util.task.CancellationToken;
import net.caffeinemc.mods.sodium.client.world.LevelSlice;
// Greedy Water is not yet supported on the UNOBFUSCATED (26.x) branch (see
// GreedyEligibility.isGreedyWaterSource) — the fabric-api fluid-rendering module's jar-in-jar
// resolution differs there and hasn't been verified.
//? if UNOBFUSCATED {

//?} else {
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
//?}
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
//? if UNOBFUSCATED {
/*import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
*///?} else if >=1.21.11 {
/*import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
*///?} else {
import net.minecraft.client.renderer.RenderType;
//?}
//? if UNOBFUSCATED {
/*import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
*///?} else {
import net.minecraft.client.renderer.block.model.BakedQuad;
//? if >=1.21.5 {
/*import net.minecraft.client.renderer.block.model.BlockModelPart;
import net.minecraft.client.renderer.block.model.BlockStateModel;
*///?} else {
import net.minecraft.client.resources.model.BakedModel;
//?}
import net.minecraft.world.level.BlockAndTintGetter;
//?}
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import hi.sierra.greedy_meshing.GreedyConfig;
import hi.sierra.greedy_meshing.GreedyEligibility;
import hi.sierra.greedy_meshing.GreedyMesher;
import hi.sierra.greedy_meshing.client.GreedyColorLightCompat;
import hi.sierra.greedy_meshing.client.GreedyDebugStore;
import hi.sierra.greedy_meshing.client.GreedyEmissiveSupport;
import hi.sierra.greedy_meshing.client.GreedyLighting;
import hi.sierra.greedy_meshing.client.GreedyPerformanceStats;
import hi.sierra.greedy_meshing.client.GreedyRuntimeState;
import hi.sierra.greedy_meshing.client.GreedySectionCache;
import hi.sierra.greedy_meshing.client.GreedySpriteSupport;
import hi.sierra.greedy_meshing.client.sodium.GreedySodiumWorkState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

@Mixin(ChunkBuilderMeshingTask.class)
public abstract class SodiumChunkBuilderMeshingTaskMixin {
    @Unique
    private static final Logger GREEDY_MESHING$LOGGER = LoggerFactory.getLogger("greedy_meshing");
    @Unique
    private static final ThreadLocal<GreedySodiumWorkState> GREEDY_MESHING$STATE = ThreadLocal.withInitial(GreedySodiumWorkState::new);
    @Unique
    private static final Direction[] GREEDY_MESHING$FACES = Direction.values();
    @Unique
    private static final ThreadLocal<BitSet[]> GREEDY_MESHING$VISIBLE = ThreadLocal.withInitial(GreedyMesher::createFaceMaskArray);
    @Inject(method = "execute", at = @At("HEAD"))
    private void greedyMeshing$beginSodiumTask(
            ChunkBuildContext buildContext,
            CancellationToken cancellationToken,
            CallbackInfoReturnable<ChunkBuildOutput> cir
    ) {
        RenderSection render = ((SodiumChunkBuilderTaskAccessor) (Object) this).greedyMeshing$getRender();
        GreedySodiumWorkState work = GREEDY_MESHING$STATE.get();
        work.reset(buildContext);
        work.sectionOrigin(new BlockPos(render.getOriginX(), render.getOriginY(), render.getOriginZ()));
        work.sectionKey(SectionPos.asLong(render.getChunkX(), render.getChunkY(), render.getChunkZ()));
        GreedyDebugStore.clearSection(work.sectionKey());
        GreedyPerformanceStats.clearSectionGeometry(work.sectionKey());
        work.world(getWorldSlice(buildContext));
        GreedyMesher.clearFaceMaskArray(GREEDY_MESHING$VISIBLE.get());
        GreedyPerformanceStats.onSodiumTaskHook();
    }

    @Inject(method = "execute", at = @At("RETURN"))
    private void greedyMeshing$endSodiumTask(
            ChunkBuildContext buildContext,
            CancellationToken cancellationToken,
            CallbackInfoReturnable<ChunkBuildOutput> cir
    ) {
        // Keep the (large, reusable) work state on its worker thread and just drop the references
        // into this build. Removing it reallocated ~200 KiB of arrays for every single section.
        GREEDY_MESHING$STATE.get().release();
    }

    //? if UNOBFUSCATED {
    /*@Redirect(
            method = "execute",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/pipeline/BlockRenderer;renderModel(Lnet/minecraft/client/renderer/block/dispatch/BlockStateModel;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V"
            )
    )
    private void greedyMeshing$redirectSodiumRenderModel(
            BlockRenderer renderer,
            BlockStateModel model,
            BlockState state,
            BlockPos worldPos,
            BlockPos modelOffset
    ) {
        GreedySodiumWorkState work = GREEDY_MESHING$STATE.get();
        if (!work.greedyActive()) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        work.blockRenderer(renderer);
        if (work.world() == null) {
            work.world(getWorldSlice(work.buildContext()));
        }

        if (work.world() == null || work.sectionOrigin() == null) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        if (!greedyMeshing$isEligible(work, state, worldPos)) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }
        // ColorLight in vertex-colour mode bakes its light into the model quads, which merged quads
        // bypass: keep blocks next to coloured light on the normal path (no-op in GPU mode).
        if (GreedyColorLightCompat.mustStayPerBlock(worldPos.getX(), worldPos.getY(), worldPos.getZ())) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        int localX = modelOffset.getX();
        int localY = modelOffset.getY();
        int localZ = modelOffset.getZ();
        if (localX < 0 || localX >= 16 || localY < 0 || localY >= 16 || localZ < 0 || localZ >= 16) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }
        int idx = GreedyMesher.index(localX, localY, localZ);
        if (work.sectionStates()[idx] == null) {
            work.incrementEligibleCount();
        }
        work.sectionStates()[idx] = state;
    }
    *///?} else if >=1.21.5 {
    /*@Redirect(
            method = "execute",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/pipeline/BlockRenderer;renderModel(Lnet/minecraft/client/renderer/block/model/BlockStateModel;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V"
            )
    )
    private void greedyMeshing$redirectSodiumRenderModel(
            BlockRenderer renderer,
            BlockStateModel model,
            BlockState state,
            BlockPos worldPos,
            BlockPos modelOffset
    ) {
        GreedySodiumWorkState work = GREEDY_MESHING$STATE.get();
        if (!work.greedyActive()) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        work.blockRenderer(renderer);
        if (work.world() == null) {
            work.world(getWorldSlice(work.buildContext()));
        }

        if (work.world() == null || work.sectionOrigin() == null) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        if (!greedyMeshing$isEligible(work, state, worldPos)) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }
        // ColorLight in vertex-colour mode bakes its light into the model quads, which merged quads
        // bypass: keep blocks next to coloured light on the normal path (no-op in GPU mode).
        if (GreedyColorLightCompat.mustStayPerBlock(worldPos.getX(), worldPos.getY(), worldPos.getZ())) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        int localX = modelOffset.getX();
        int localY = modelOffset.getY();
        int localZ = modelOffset.getZ();
        if (localX < 0 || localX >= 16 || localY < 0 || localY >= 16 || localZ < 0 || localZ >= 16) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }
        int idx = GreedyMesher.index(localX, localY, localZ);
        if (work.sectionStates()[idx] == null) {
            work.incrementEligibleCount();
        }
        work.sectionStates()[idx] = state;
    }
    *///?} else {
    @Redirect(
            method = "execute",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/pipeline/BlockRenderer;renderModel(Lnet/minecraft/client/resources/model/BakedModel;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V"
            )
    )
    private void greedyMeshing$redirectSodiumRenderModel(
            BlockRenderer renderer,
            BakedModel model,
            BlockState state,
            BlockPos worldPos,
            BlockPos modelOffset
    ) {
        GreedySodiumWorkState work = GREEDY_MESHING$STATE.get();
        if (!work.greedyActive()) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        work.blockRenderer(renderer);
        if (work.world() == null) {
            work.world(getWorldSlice(work.buildContext()));
        }

        if (work.world() == null || work.sectionOrigin() == null) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        if (!greedyMeshing$isEligible(work, state, worldPos)) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }
        // ColorLight in vertex-colour mode bakes its light into the model quads, which merged quads
        // bypass: keep blocks next to coloured light on the normal path (no-op in GPU mode).
        if (GreedyColorLightCompat.mustStayPerBlock(worldPos.getX(), worldPos.getY(), worldPos.getZ())) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }

        int localX = modelOffset.getX();
        int localY = modelOffset.getY();
        int localZ = modelOffset.getZ();
        if (localX < 0 || localX >= 16 || localY < 0 || localY >= 16 || localZ < 0 || localZ >= 16) {
            renderer.renderModel(model, state, worldPos, modelOffset);
            return;
        }
        int idx = GreedyMesher.index(localX, localY, localZ);
        if (work.sectionStates()[idx] == null) {
            work.incrementEligibleCount();
        }
        work.sectionStates()[idx] = state;
    }
    //?}

    @Unique
    private static boolean greedyMeshing$isEligible(GreedySodiumWorkState work, BlockState state, BlockPos worldPos) {
        if (work.hasVerdictFor(state)) {
            return work.lastVerdictFor(state);
        }
        boolean verdict = GreedyEligibility.isGreedyOpaqueCube(state, work.world(), worldPos)
                && GreedySpriteSupport.supportsGreedySpriteSizes(state);
        work.rememberVerdict(state, verdict);
        return verdict;
    }

    /**
     * Water's fluid quads go through Sodium's own FluidRenderer.render(...), a code path entirely
     * separate from BlockRenderer.renderModel above — BlockState.getRenderShape() for water is
     * INVISIBLE, so the renderModel redirects above never see it. Only plain still-water source
     * blocks that pass GreedyEligibility.isGreedyWaterSource are captured; everything else falls
     * through to Sodium's normal per-block fluid rendering.
     */
    @Redirect(
            method = "execute",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/pipeline/FluidRenderer;render(Lnet/caffeinemc/mods/sodium/client/world/LevelSlice;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/material/FluidState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/caffeinemc/mods/sodium/client/render/chunk/translucent_sorting/TranslucentGeometryCollector;Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/ChunkBuildBuffers;)V"
            )
    )
    private void greedyMeshing$redirectSodiumFluidRender(
            FluidRenderer renderer,
            LevelSlice levelSlice,
            BlockState state,
            FluidState fluidState,
            BlockPos worldPos,
            BlockPos modelOffset,
            TranslucentGeometryCollector collector,
            ChunkBuildBuffers buffers
    ) {
        try {
            greedyMeshing$redirectSodiumFluidRender0(renderer, levelSlice, state, fluidState, worldPos, modelOffset, collector, buffers);
        } catch (Throwable t) {
            if (!GREEDY_MESHING$FLUID_REDIRECT_ERROR_LOGGED) {
                GREEDY_MESHING$FLUID_REDIRECT_ERROR_LOGGED = true;
                GREEDY_MESHING$LOGGER.error("Greedy Meshing: exception capturing water block at {} for merging — "
                        + "falling back to normal rendering for this block. This warning only prints once.", worldPos, t);
            }
            renderer.render(levelSlice, state, fluidState, worldPos, modelOffset, collector, buffers);
        }
    }

    @Unique
    private static volatile boolean GREEDY_MESHING$FLUID_REDIRECT_ERROR_LOGGED = false;

    @Unique
    private void greedyMeshing$redirectSodiumFluidRender0(
            FluidRenderer renderer,
            LevelSlice levelSlice,
            BlockState state,
            FluidState fluidState,
            BlockPos worldPos,
            BlockPos modelOffset,
            TranslucentGeometryCollector collector,
            ChunkBuildBuffers buffers
    ) {
        GreedySodiumWorkState work = GREEDY_MESHING$STATE.get();
        if (!work.greedyActive()) {
            renderer.render(levelSlice, state, fluidState, worldPos, modelOffset, collector, buffers);
            return;
        }

        if (work.world() == null) {
            work.world(getWorldSlice(work.buildContext()));
        }

        if (work.world() == null || work.sectionOrigin() == null
                || !GreedyEligibility.isGreedyWaterSource(state, work.world(), worldPos)) {
            renderer.render(levelSlice, state, fluidState, worldPos, modelOffset, collector, buffers);
            return;
        }

        int localX = modelOffset.getX();
        int localY = modelOffset.getY();
        int localZ = modelOffset.getZ();
        if (localX < 0 || localX >= 16 || localY < 0 || localY >= 16 || localZ < 0 || localZ >= 16) {
            renderer.render(levelSlice, state, fluidState, worldPos, modelOffset, collector, buffers);
            return;
        }
        int idx = GreedyMesher.index(localX, localY, localZ);
        if (work.sectionStates()[idx] == null) {
            work.incrementEligibleCount();
        }
        work.sectionStates()[idx] = state;
    }

    @Inject(
            method = "execute",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/caffeinemc/mods/sodium/client/render/chunk/compile/pipeline/BlockRenderer;release()V"
            )
    )
    private void greedyMeshing$emitGreedyBeforeSodiumMeshBuild(
            ChunkBuildContext buildContext,
            CancellationToken cancellationToken,
            CallbackInfoReturnable<ChunkBuildOutput> cir
    ) {
        GreedySodiumWorkState work = GREEDY_MESHING$STATE.get();
        if (!work.greedyActive()) {
            return;
        }

        if (work.eligibleCount() <= 0 || work.sectionOrigin() == null || work.blockRenderer() == null) {
            return;
        }

        if (work.world() == null) {
            work.world(getWorldSlice(buildContext));
            if (work.world() == null) {
                return;
            }
        }

        try {
            ChunkBuildBuffers buffers = ((SodiumChunkBuildContextAccessor) (Object) buildContext).greedyMeshing$getBuffers();
            TranslucentGeometryCollector collector = ((SodiumBlockRendererAccessor) (Object) work.blockRenderer()).greedyMeshing$getCollector();

            int baseX = work.sectionOrigin().getX();
            int baseY = work.sectionOrigin().getY();
            int baseZ = work.sectionOrigin().getZ();
            work.scratchLighting.applyDirectionalShade =
                    !GreedyRuntimeState.isInSableSubLevel(baseX >> 4, baseZ >> 4);
            BitSet[] visibleFaces = GREEDY_MESHING$VISIBLE.get();
            long[][] mergeKeys = work.faceMergeKeys();
            GreedySectionCache sectionCache = work.sectionCache;
            sectionCache.begin(work.world(), baseX, baseY, baseZ);
            work.scratchLighting.cache = sectionCache;
            populateFaceVisibility(work.world(), sectionCache, work.sectionStates(), visibleFaces, mergeKeys, baseX, baseY, baseZ);
            List<GreedyMesher.GreedyQuad> merged = GreedyMesher.meshWithKeys(
                    work.sectionStates(), visibleFaces, mergeKeys
            );

            List<GreedyDebugStore.DebugQuad> debugQuads = work.captureDebug() ? new ArrayList<>(merged.size()) : List.of();
            int emittedQuads = 0;
            int vanillaEquivalent = 0;
            boolean shaderPackActive = GreedyRuntimeState.isShaderPackActive();
            for (GreedyMesher.GreedyQuad quad : merged) {
                List<FaceAppearance> layers = greedyMeshing$resolveFaceLayers(quad.state(), quad.face());
                int blockFaces = quad.width() * quad.height();
                for (FaceAppearance layer : layers) {
                    // Get the correct Sodium material/buffer for this block type
                    //? if UNOBFUSCATED {
                    /*net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.Material material = DefaultMaterials.forChunkLayer(layer.layer());
                    *///?} else {
                    // DefaultMaterials.forBlockState resolves via the same block->RenderType table
                    // ItemBlockRenderTypes.getChunkRenderType uses, which fluids are never registered in
                    // (they're keyed by Fluid instead) — water needs the fluid-specific overload or it
                    // silently resolves to the SOLID material.
                    net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.Material material =
                            quad.state().is(Blocks.WATER)
                                    ? DefaultMaterials.forFluidState(quad.state().getFluidState())
                                    : DefaultMaterials.forBlockState(quad.state());
                    //?}
                    ChunkModelBuilder modelBuilder = buffers.get(material);
                    VertexConsumer consumer = modelBuilder.asFallbackVertexConsumer(material, collector);
                    if (consumer == null) continue;

                    if (shaderPackActive || !GreedySpriteSupport.supportsMergedShaderSprite(layer.sprite())) {
                        emittedQuads += emitTiledQuads(consumer, quad,
                                layer.sprite().getU0(), layer.sprite().getU1(),
                                layer.sprite().getV0(), layer.sprite().getV1(),
                                layer.tinted(), layer.tintIndex(), work.world(), baseX, baseY, baseZ, work, false);
                    } else {
                        emittedQuads += emitMergedQuad(consumer, quad,
                                layer.sprite().getU0(), layer.sprite().getU1(),
                                layer.sprite().getV0(), layer.sprite().getV1(),
                                layer.tinted(), layer.tintIndex(), work.world(), baseX, baseY, baseZ, work,
                                layer.sprite().contents().width(), visibleFaces[quad.face().ordinal()]);
                    }
                    TextureAtlasSprite emissive = GreedyEmissiveSupport.find(layer.sprite());
                    if (emissive != null) {
                        // _e textures contain transparent pixels around the glowing pixels.  On
                        // 26.2, keep this overlay in Sodium's cutout material; putting it in the
                        // solid material makes the transparent background opaque and stretches a
                        // dark/bright copy over the whole ore face.
                        //? if UNOBFUSCATED {
                        /*net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.Material emissiveMaterial =
                                DefaultMaterials.forChunkLayer(ChunkSectionLayer.CUTOUT);
                        ChunkModelBuilder emissiveModelBuilder = buffers.get(emissiveMaterial);
                        VertexConsumer emissiveConsumer = emissiveModelBuilder.asFallbackVertexConsumer(emissiveMaterial, collector);
                        if (emissiveConsumer != null) {
                            emittedQuads += emitTiledQuads(emissiveConsumer, quad,
                                    emissive.getU0(), emissive.getU1(), emissive.getV0(), emissive.getV1(),
                                    false, -1, work.world(), baseX, baseY, baseZ, work, true);
                        }
                        *///?} else {
                        //? if >=1.21.11 {
                        /*net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.Material emissiveMaterial =
                                DefaultMaterials.forChunkLayer(ChunkSectionLayer.CUTOUT);
                        *///?} else {
                        net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.Material emissiveMaterial = DefaultMaterials.CUTOUT;
                        //?}
                        ChunkModelBuilder emissiveModelBuilder = buffers.get(emissiveMaterial);
                        VertexConsumer emissiveConsumer = emissiveModelBuilder.asFallbackVertexConsumer(emissiveMaterial, collector);
                        if (emissiveConsumer != null) {
                            emittedQuads += emitTiledQuads(emissiveConsumer, quad,
                                    emissive.getU0(), emissive.getU1(), emissive.getV0(), emissive.getV1(),
                                    false, -1, work.world(), baseX, baseY, baseZ, work, true);
                        }
                        //?}
                    }
                    vanillaEquivalent += blockFaces;
                }
                if (work.captureDebug()) {
                    debugQuads.add(toDebugQuad(quad, baseX, baseY, baseZ, work.world(), work.scratchTintPos));
                }
            }
            if (!merged.isEmpty()) {
                GreedyPerformanceStats.onGreedySectionBuilt(work.eligibleCount(), merged.size(), emittedQuads, vanillaEquivalent);
                GreedyPerformanceStats.setSectionGeometry(work.sectionKey(), emittedQuads, vanillaEquivalent);
            }

            if (work.captureDebug()) {
                GreedyDebugStore.setSectionQuads(work.sectionKey(), debugQuads);
            }
        } catch (Throwable t) {
            GREEDY_MESHING$LOGGER.error("Greedy Meshing: exception while emitting merged quads for section at {} — "
                    + "this section's greedy geometry (and possibly the whole chunk build) was lost", work.sectionOrigin(), t);
        }
    }

    @Unique
    private static BlockAndTintGetter getWorldSlice(ChunkBuildContext context) {
        BlockRenderCache cache = ((SodiumChunkBuildContextAccessor) (Object) context).greedyMeshing$getCache();
        return cache.getWorldSlice();
    }

    @Unique
    private static GreedyDebugStore.DebugQuad toDebugQuad(
            GreedyMesher.GreedyQuad quad, int baseX, int baseY, int baseZ,
            BlockAndTintGetter world, BlockPos.MutableBlockPos scratch
    ) {
        float top = greedyMeshing$waterSurfaceTop(world, quad, baseX, baseY, baseZ, scratch);
        float[] c = corners(quad, top);
        return new GreedyDebugStore.DebugQuad(
                c[0] + baseX, c[1] + baseY, c[2] + baseZ,
                c[3] + baseX, c[4] + baseY, c[5] + baseZ,
                c[6] + baseX, c[7] + baseY, c[8] + baseZ,
                c[9] + baseX, c[10] + baseY, c[11] + baseZ
        );
    }

    @Unique
    private static final java.util.concurrent.ConcurrentHashMap<BlockState, List<FaceAppearance>[]> GREEDY_MESHING$LAYER_CACHE =
            new java.util.concurrent.ConcurrentHashMap<>();
    @Unique
    private static volatile int GREEDY_MESHING$LAYER_GENERATION = -1;

    /**
     * Resolving a face walked the baked model and allocated a RandomSource and lists for every merged
     * quad. The answer only depends on (state, face) until resources reload or settings change, which
     * is exactly when {@link GreedySpriteSupport#generation()} moves.
     */
    @Unique
    @SuppressWarnings("unchecked")
    private static List<FaceAppearance> greedyMeshing$resolveFaceLayers(BlockState state, Direction face) {
        int generation = GreedySpriteSupport.generation();
        if (generation != GREEDY_MESHING$LAYER_GENERATION) {
            GREEDY_MESHING$LAYER_CACHE.clear();
            GREEDY_MESHING$LAYER_GENERATION = generation;
        }
        List<FaceAppearance>[] perFace = GREEDY_MESHING$LAYER_CACHE.get(state);
        if (perFace == null) {
            perFace = new List[6];
            List<FaceAppearance>[] existing = GREEDY_MESHING$LAYER_CACHE.putIfAbsent(state, perFace);
            if (existing != null) {
                perFace = existing;
            }
        }
        int fi = face.ordinal();
        List<FaceAppearance> cached = perFace[fi];
        if (cached == null) {
            cached = List.copyOf(greedyMeshing$resolveFaceLayersUncached(state, face));
            if (generation == GreedySpriteSupport.generation()) {
                perFace[fi] = cached;
            }
        }
        return cached;
    }

    @Unique
    private static List<FaceAppearance> greedyMeshing$resolveFaceLayersUncached(BlockState state, Direction face) {
        if (state.is(Blocks.WATER)) {
            return greedyMeshing$resolveWaterFaceLayers(state);
        }
        //? if UNOBFUSCATED {
        /*BlockStateModel model = Minecraft.getInstance().getModelManager().getBlockStateModelSet().get(state);
        RandomSource random = RandomSource.create(0L);
        List<BlockStateModelPart> parts = new java.util.ArrayList<>();
        model.collectParts(random, parts);
        List<FaceAppearance> layers = new java.util.ArrayList<>();
        for (BlockStateModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(face)) {
                layers.add(new FaceAppearance(quad.materialInfo().sprite(), quad.materialInfo().isTinted(), quad.materialInfo().layer(), quad.materialInfo().tintIndex()));
            }
        }
        for (BlockStateModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(null)) {
                if (quad.direction() == face) {
                    layers.add(new FaceAppearance(quad.materialInfo().sprite(), quad.materialInfo().isTinted(), quad.materialInfo().layer(), quad.materialInfo().tintIndex()));
                }
            }
        }
        if (layers.isEmpty()) {
            layers.add(new FaceAppearance(model.particleMaterial().sprite(), false, ChunkSectionLayer.SOLID, -1));
        }
        *///?} else if >=1.21.5 {
        /*BlockStateModel model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
        RandomSource random = RandomSource.create(0L);
        List<BlockModelPart> parts = model.collectParts(random);
        List<FaceAppearance> layers = new java.util.ArrayList<>();
        for (BlockModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(face)) {
                layers.add(new FaceAppearance(quad.sprite(), quad.isTinted(), quad.tintIndex()));
            }
        }
        for (BlockModelPart part : parts) {
            for (BakedQuad quad : part.getQuads(null)) {
                if (quad.direction() == face) {
                    layers.add(new FaceAppearance(quad.sprite(), quad.isTinted(), quad.tintIndex()));
                }
            }
        }
        if (layers.isEmpty()) {
            layers.add(new FaceAppearance(model.particleIcon(), false, -1));
        }
        *///?} else {
        BakedModel model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
        RandomSource random = RandomSource.create(0L);
        List<FaceAppearance> layers = new java.util.ArrayList<>();
        for (BakedQuad quad : model.getQuads(state, face, random)) {
            layers.add(new FaceAppearance(quad.getSprite(), quad.isTinted(), quad.getTintIndex()));
        }
        for (BakedQuad quad : model.getQuads(state, null, random)) {
            if (quad.getDirection() == face) {
                layers.add(new FaceAppearance(quad.getSprite(), quad.isTinted(), quad.getTintIndex()));
            }
        }
        if (layers.isEmpty()) {
            layers.add(new FaceAppearance(model.getParticleIcon(), false, -1));
        }
        //?}
        return layers;
    }

    /**
     * Water's BlockState.getRenderShape() is INVISIBLE, so it has no real baked model — the
     * generic greedyMeshing$resolveFaceLayers path above (which looks up a baked model) doesn't
     * apply. Resolve the still-water sprite via Fabric's fluid-rendering API instead; the world
     * position doesn't matter here (Fabric's default water handler ignores it when picking the
     * sprite), only the FluidState, so this is safe to cache per-BlockState like the opaque path.
     */
    @Unique
    private static List<FaceAppearance> greedyMeshing$resolveWaterFaceLayers(BlockState state) {
        //? if UNOBFUSCATED {
        /*// Not yet wired up on this branch — see GreedyEligibility.isGreedyWaterSource, which
        // always returns false here, so this is unreachable rather than a behavior change.
        return List.of();
        *///?} else {
        // Fabric API registers a default handler for vanilla water unconditionally on init, so this
        // is never actually null in practice — GreedyEligibility.isGreedyWaterSource already gates
        // out anything that isn't plain Blocks.WATER before this is ever called.
        FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(Fluids.WATER);
        if (handler == null) {
            return List.of();
        }
        TextureAtlasSprite sprite = handler.getFluidSprites(null, null, state.getFluidState())[0];
        return List.of(new FaceAppearance(sprite, true, -1));
        //?}
    }

    @Unique
    private static void populateFaceVisibility(
            BlockAndTintGetter world,
            GreedySectionCache cache,
            BlockState[] sectionStates,
            BitSet[] visibleFaces,
            long[][] faceMergeKeys,
            int baseX,
            int baseY,
            int baseZ
    ) {
        GreedyMesher.clearFaceMaskArray(visibleFaces);
        BlockPos.MutableBlockPos samplePos = new BlockPos.MutableBlockPos();
        for (int y = 0; y < GreedyMesher.SECTION_SIZE; y++) {
            for (int z = 0; z < GreedyMesher.SECTION_SIZE; z++) {
                for (int x = 0; x < GreedyMesher.SECTION_SIZE; x++) {
                    int idx = GreedyMesher.index(x, y, z);
                    BlockState state = sectionStates[idx];
                    if (state == null) {
                        continue;
                    }

                    int worldX = baseX + x;
                    int worldY = baseY + y;
                    int worldZ = baseZ + z;
                    for (Direction face : GREEDY_MESHING$FACES) {
                        int nx = x + face.getStepX();
                        int ny = y + face.getStepY();
                        int nz = z + face.getStepZ();
                        if (nx >= 0 && nx < GreedyMesher.SECTION_SIZE
                                && ny >= 0 && ny < GreedyMesher.SECTION_SIZE
                                && nz >= 0 && nz < GreedyMesher.SECTION_SIZE
                                && sectionStates[GreedyMesher.index(nx, ny, nz)] != null) {
                            continue;
                        }

                        samplePos.set(worldX + face.getStepX(), worldY + face.getStepY(), worldZ + face.getStepZ());
                        BlockState neighbor = cache.state(samplePos.getX(), samplePos.getY(), samplePos.getZ());
                        //? if >=1.21.2 {
                        if (Block.shouldRenderFace(state, neighbor, face)) {
                        //?} else {
                        /*if (Block.shouldRenderFace(state, world, new BlockPos(worldX, worldY, worldZ), face, samplePos)) {
                        *///?}
                            visibleFaces[face.ordinal()].set(idx);
                            int mergeKey;
                            if (state.is(Blocks.WATER)) {
                                // Water only merges within the interior of a flat, uncovered still-water
                                // body (see GreedyEligibility.isGreedyWaterSource + isFlatWaterSurface) —
                                // vanilla renders a sloped, per-corner-averaged surface everywhere else,
                                // which this mod's flat GreedyQuad rectangles can't represent. The bottom
                                // face is always an exact flat square regardless of the top surface's
                                // slope, so it skips the check; every other face (including the sides,
                                // whose top edge follows the same slope as the top face) needs it.
                                // Non-flat faces get a unique key so they fall back to individual 1x1
                                // quads — pixel-identical to un-merged vanilla rendering, never a
                                // regression.
                                boolean flat = face == Direction.DOWN
                                        || isFlatWaterSurface(world, worldX, worldY, worldZ, samplePos);
                                mergeKey = flat ? 0 : (0x40000000 | idx);
                            } else {
                                // Aggressive ("absolute") greedy ignores the AO signature so same-block
                                // faces merge into the largest possible quads; lighting is still sampled
                                // per sub-quad.
                                mergeKey = GreedyConfig.aggressiveGreedy()
                                        ? 0
                                        : computeAoKey(cache, worldX, worldY, worldZ, face);
                            }
                            faceMergeKeys[face.ordinal()][idx] = mergeKey;
                        }
                    }
                }
            }
        }
    }

    /**
     * True iff the 3x3 horizontal neighbourhood centered on (worldX, worldY, worldZ) is entirely
     * uncovered still-water source blocks — the union of the four lattice corners vanilla's own
     * per-corner height averaging touches for this block's top face. Checking the superset rather
     * than each corner's exact 2x2 footprint is conservative: a handful of tiles that would actually
     * render flat get misclassified as non-flat (and simply don't merge), which is acceptable —
     * this check only ever removes merge opportunities, never approves an incorrect one.
     */
    @Unique
    private static boolean isFlatWaterSurface(
            BlockAndTintGetter world, int worldX, int worldY, int worldZ, BlockPos.MutableBlockPos scratch
    ) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                scratch.set(worldX + dx, worldY, worldZ + dz);
                BlockState neighborState = world.getBlockState(scratch);
                if (!neighborState.is(Blocks.WATER)) {
                    return false;
                }
                FluidState neighborFluid = neighborState.getFluidState();
                if (!neighborFluid.isSource() || neighborFluid.getType() != Fluids.WATER) {
                    return false;
                }
                scratch.set(worldX + dx, worldY + 1, worldZ + dz);
                if (world.getBlockState(scratch).getFluidState().getType() == Fluids.WATER) {
                    return false;
                }
            }
        }
        return true;
    }

    @Unique
    private static final int[][][] GREEDY_MESHING$AO_OFFSETS = new int[6][8][3];
    static {
        Direction[] faces = Direction.values();
        for (Direction face : faces) {
            int ax1, ay1, az1, ax2, ay2, az2;
            switch (face) {
                case DOWN, UP     -> { ax1=1; ay1=0; az1=0; ax2=0; ay2=0; az2=1; }
                case NORTH, SOUTH -> { ax1=1; ay1=0; az1=0; ax2=0; ay2=1; az2=0; }
                default           -> { ax1=0; ay1=0; az1=1; ax2=0; ay2=1; az2=0; }
            }
            int idx = 0;
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    GREEDY_MESHING$AO_OFFSETS[face.ordinal()][idx][0] = face.getStepX() + a * ax1 + b * ax2;
                    GREEDY_MESHING$AO_OFFSETS[face.ordinal()][idx][1] = face.getStepY() + a * ay1 + b * ay2;
                    GREEDY_MESHING$AO_OFFSETS[face.ordinal()][idx][2] = face.getStepZ() + a * az1 + b * az2;
                    idx++;
                }
            }
        }
    }

    @Unique
    private static int computeAoKey(GreedySectionCache cache,
                                    int worldX, int worldY, int worldZ, Direction face) {
        int[][] offsets = GREEDY_MESHING$AO_OFFSETS[face.ordinal()];
        int key = 0;
        for (int i = 0; i < 8; i++) {
            // occludes() is the same predicate the old inline test used (isLightPermeable on 26.3,
            // isViewBlocking + light dampening before), evaluated once per cell instead of per face.
            if (cache.occludes(worldX + offsets[i][0], worldY + offsets[i][1], worldZ + offsets[i][2])) {
                key |= (1 << i);
            }
        }
        int packedLight = cache.light(worldX + face.getStepX(), worldY + face.getStepY(), worldZ + face.getStepZ());
        key |= ((packedLight >>> 4) & 0xF) << 8;
        key |= ((packedLight >>> 20) & 0xF) << 12;
        return key;
    }

    private static final int GREEDY_MESHING$LIGHT_STEP = 4;

    @Unique
    private static int emitMergedQuad(
            VertexConsumer consumer, GreedyMesher.GreedyQuad quad,
            float u0, float u1, float v0, float v1,
            boolean applyTint, int tintIndex, BlockAndTintGetter world,
            int baseX, int baseY, int baseZ,
            GreedySodiumWorkState work,
            int spriteSize,
            BitSet visible
    ) {
        int W = quad.width(), H = quad.height();
        if (W == 1 && H == 1) {
            emitSodiumSubQuad(consumer, quad, 0, 0, 1, 1, W, H, u0, u1, v0, v1,
                    applyTint, tintIndex, world, baseX, baseY, baseZ, work, true, spriteSize, 0);
            return 1;
        }
        int skirtMask = greedyMeshing$computeSkirtMask(visible, quad.face(), quad.x(), quad.y(), quad.z(), W, H);
        int count = 0;
        for (int sv = 0; sv < H; sv += GREEDY_MESHING$LIGHT_STEP) {
            int sh = Math.min(GREEDY_MESHING$LIGHT_STEP, H - sv);
            for (int su = 0; su < W; su += GREEDY_MESHING$LIGHT_STEP) {
                int sw = Math.min(GREEDY_MESHING$LIGHT_STEP, W - su);
                emitSodiumSubQuad(consumer, quad, su, sv, sw, sh, W, H, u0, u1, v0, v1,
                        applyTint, tintIndex, world, baseX, baseY, baseZ, work, false, spriteSize, skirtMask);
                count++;
            }
        }
        return count;
    }

    /**
     * Bitmask (1=uMin, 2=uMax, 4=vMin, 8=vMax) of which outer edges of a merged quad are safe to
     * crack-skirt: either the true edge of the 16-block section (the original cross-section T-junction
     * case this fix targets), or an edge that actually borders more visible same-direction geometry
     * (a real seam between two separately-meshed quads). An edge with neither is a genuine silhouette
     * — e.g. a block corner where a perpendicular face meets — and nudging it outward there pushes the
     * quad past the true geometric boundary into that other face's space instead of closing a gap.
     */
    @Unique
    private static int greedyMeshing$computeSkirtMask(BitSet visible, Direction face, int qx, int qy, int qz, int w, int h) {
        int uStart, vStart;
        switch (face) {
            case NORTH, SOUTH -> { uStart = qx; vStart = qy; }
            case WEST, EAST   -> { uStart = qz; vStart = qy; }
            default           -> { uStart = qx; vStart = qz; } // DOWN, UP
        }
        int mask = 0;
        if (uStart == 0 || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, -1, 0)) mask |= 1;
        if (uStart + w == GreedyMesher.SECTION_SIZE || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, 1, 0)) mask |= 2;
        if (vStart == 0 || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, 0, -1)) mask |= 4;
        if (vStart + h == GreedyMesher.SECTION_SIZE || greedyMeshing$edgeHasNeighbor(visible, face, qx, qy, qz, w, h, 0, 1)) mask |= 8;
        return mask;
    }

    @Unique
    private static boolean greedyMeshing$edgeHasNeighbor(BitSet visible, Direction face, int qx, int qy, int qz, int w, int h, int du, int dv) {
        if (du != 0) {
            int u = du < 0 ? -1 : w;
            for (int v = 0; v < h; v++) {
                if (greedyMeshing$cellVisible(visible, face, qx, qy, qz, u, v)) return true;
            }
        } else {
            int v = dv < 0 ? -1 : h;
            for (int u = 0; u < w; u++) {
                if (greedyMeshing$cellVisible(visible, face, qx, qy, qz, u, v)) return true;
            }
        }
        return false;
    }

    @Unique
    private static boolean greedyMeshing$cellVisible(BitSet visible, Direction face, int qx, int qy, int qz, int u, int v) {
        int x, y, z;
        switch (face) {
            case NORTH, SOUTH -> { x = qx + u; y = qy + v; z = qz; }
            case WEST, EAST   -> { x = qx; y = qy + v; z = qz + u; }
            default           -> { x = qx + u; y = qy; z = qz + v; } // DOWN, UP
        }
        if (x < 0 || x >= GreedyMesher.SECTION_SIZE || y < 0 || y >= GreedyMesher.SECTION_SIZE || z < 0 || z >= GreedyMesher.SECTION_SIZE) {
            return false;
        }
        return visible.get(GreedyMesher.index(x, y, z));
    }

    /** World-space overlap nudged onto a merged quad's outer edge to hide sub-pixel raster
     *  gaps ("T-junction cracks") some GPU drivers leave between it and neighboring quads that
     *  were meshed independently. Small enough to be visually imperceptible. */
    @Unique
    private static final float GREEDY_MESHING$CRACK_SKIRT = 1f / 128f;

    // (uSide, vSide) per corner index, matching the cornersInto winding below: +1 means the
    // corner sits on that axis's max edge, -1 its min edge. Indexed by Direction.ordinal()
    // (DOWN, UP, NORTH, SOUTH, WEST, EAST).
    @Unique
    private static final int[][] GREEDY_MESHING$CORNER_UV_SIDES = {
            { -1, -1,  1, -1,  1,  1, -1,  1 }, // DOWN
            { -1,  1,  1,  1,  1, -1, -1, -1 }, // UP
            {  1, -1, -1, -1, -1,  1,  1,  1 }, // NORTH
            { -1, -1,  1, -1,  1,  1, -1,  1 }, // SOUTH
            { -1, -1,  1, -1,  1,  1, -1,  1 }, // WEST
            {  1, -1, -1, -1, -1,  1,  1,  1 }, // EAST
    };

    @Unique
    private static void greedyMeshing$skirtCorners(float[] c, Direction face, boolean atUMin, boolean atUMax, boolean atVMin, boolean atVMax) {
        if (!atUMin && !atUMax && !atVMin && !atVMax) {
            return;
        }
        int axisU = (face == Direction.WEST || face == Direction.EAST) ? 2 : 0;
        int axisV = (face == Direction.DOWN || face == Direction.UP) ? 2 : 1;
        int[] sides = GREEDY_MESHING$CORNER_UV_SIDES[face.ordinal()];
        for (int i = 0; i < 4; i++) {
            int uSide = sides[i * 2];
            int vSide = sides[i * 2 + 1];
            int ci = i * 3;
            if ((uSide < 0 && atUMin) || (uSide > 0 && atUMax)) {
                c[ci + axisU] += uSide * GREEDY_MESHING$CRACK_SKIRT;
            }
            if ((vSide < 0 && atVMin) || (vSide > 0 && atVMax)) {
                c[ci + axisV] += vSide * GREEDY_MESHING$CRACK_SKIRT;
            }
        }
    }

    @Unique
    private static void emitSodiumSubQuad(
            VertexConsumer consumer, GreedyMesher.GreedyQuad quad,
            int offU, int offV, int subW, int subH, int fullW, int fullH,
            float u0, float u1, float v0, float v1,
            boolean applyTint, int tintIndex, BlockAndTintGetter world,
            int baseX, int baseY, int baseZ,
            GreedySodiumWorkState work,
            boolean fullAO,
            int spriteSize,
            int skirtMask
    ) {
        Direction face = quad.face();
        int qx = quad.x(), qy = quad.y(), qz = quad.z();
        int sx, sy, sz;
        switch (face) {
            case NORTH, SOUTH -> { sx = qx + offU; sy = qy + offV; sz = qz; }
            case WEST, EAST   -> { sx = qx; sy = qy + offV; sz = qz + offU; }
            case DOWN, UP     -> { sx = qx + offU; sy = qy; sz = qz + offV; }
            default -> { sx = qx; sy = qy; sz = qz; }
        }

        GreedyMesher.GreedyQuad sub = new GreedyMesher.GreedyQuad(face, sx, sy, sz, subW, subH, quad.state());

        float[] c = work.scratchCorners;
        float top = greedyMeshing$waterSurfaceTop(world, sub, baseX, baseY, baseZ, work.scratchTintPos);
        cornersInto(sub, c, top);
        if (!fullAO && GreedyRuntimeState.requiresCrackSafeSubdivision()) {
            greedyMeshing$skirtCorners(c, face,
                    offU == 0 && (skirtMask & 1) != 0,
                    offU + subW == fullW && (skirtMask & 2) != 0,
                    offV == 0 && (skirtMask & 4) != 0,
                    offV + subH == fullH && (skirtMask & 8) != 0);
        }
        float nx = face.getStepX(), ny = face.getStepY(), nz = face.getStepZ();
        boolean flipV = face.getAxis().isHorizontal();
        float vv0 = flipV ? v1 : v0, vv1 = flipV ? v0 : v1;
        BlockColors blockColors = applyTint ? Minecraft.getInstance().getBlockColors() : null;
        BlockPos.MutableBlockPos tintPos = work.scratchTintPos;
        GreedyLighting.Scratch lighting = work.scratchLighting;
        int[][] cb = work.scratchCornerBlocks;
        greedyMeshing$cornerBlockPositionsInto(sub, baseX, baseY, baseZ, cb);
        float[] brightness = work.scratchBrightness;
        float[] tintR = work.scratchTintR, tintG = work.scratchTintG, tintB = work.scratchTintB;
        int[] lightmap = work.scratchLightmap;

        for (int i = 0; i < 4; i++) {
            GreedyLighting.computeTileLighting(world, quad.state(), face, cb[i][0], cb[i][1], cb[i][2], lighting);
            brightness[i] = lighting.brightness[i];
            lightmap[i] = lighting.lightmap[i];
            int tint = applyTint ? tintColorForTile(quad.state(), world, cb[i][0], cb[i][1], cb[i][2], tintPos, blockColors, tintIndex) : 0xFFFFFF;
            tintR[i] = ((tint >> 16) & 0xFF) / 255.0f;
            tintG[i] = ((tint >> 8) & 0xFF) / 255.0f;
            tintB[i] = (tint & 0xFF) / 255.0f;
        }

        float faceAlpha = GreedySpriteSupport.mergedFaceAlpha(face, spriteSize);
        float cu = (u0 + u1) * 0.5f, cv = (vv0 + vv1) * 0.5f;
        consumer.addVertex(c[0],c[1],c[2]).setColor(brightness[0]*tintR[0],brightness[0]*tintG[0],brightness[0]*tintB[0],faceAlpha).setUv(cu,cv).setLight(lightmap[0]).setNormal(nx,ny,nz);
        consumer.addVertex(c[3],c[4],c[5]).setColor(brightness[1]*tintR[1],brightness[1]*tintG[1],brightness[1]*tintB[1],faceAlpha).setUv(cu,cv).setLight(lightmap[1]).setNormal(nx,ny,nz);
        consumer.addVertex(c[6],c[7],c[8]).setColor(brightness[2]*tintR[2],brightness[2]*tintG[2],brightness[2]*tintB[2],faceAlpha).setUv(cu,cv).setLight(lightmap[2]).setNormal(nx,ny,nz);
        consumer.addVertex(c[9],c[10],c[11]).setColor(brightness[3]*tintR[3],brightness[3]*tintG[3],brightness[3]*tintB[3],faceAlpha).setUv(cu,cv).setLight(lightmap[3]).setNormal(nx,ny,nz);
    }

    private static int emitTiledQuads(
            VertexConsumer consumer,
            GreedyMesher.GreedyQuad quad,
            float u0,
            float u1,
            float v0,
            float v1,
            boolean applyTint,
            int tintIndex,
            BlockAndTintGetter world,
            int baseX,
            int baseY,
            int baseZ,
            GreedySodiumWorkState work,
            boolean fullbright
    ) {
        float[] c = work.scratchCorners;
        BlockPos.MutableBlockPos tintPos = work.scratchTintPos;
        float top = greedyMeshing$waterSurfaceTop(world, quad, baseX, baseY, baseZ, tintPos);
        cornersInto(quad, c, top);
        float nx = quad.face().getStepX(), ny = quad.face().getStepY(), nz = quad.face().getStepZ();

        BlockColors blockColors = applyTint ? Minecraft.getInstance().getBlockColors() : null;
        GreedyLighting.Scratch lighting = work.scratchLighting;

        int W = quad.width();
        int H = quad.height();
        int count = 0;

        // Side faces need V-flip to keep textures upright (e.g., grass overlay)
        boolean flipV = quad.face().getAxis().isHorizontal();
        float vv0 = flipV ? v1 : v0;
        float vv1 = flipV ? v0 : v1;

        for (int tv = 0; tv < H; tv++) {
            for (int tu = 0; tu < W; tu++) {
                float fu0 = (float) tu / W, fu1 = (float) (tu + 1) / W;
                float fv0 = (float) tv / H, fv1 = (float) (tv + 1) / H;

                // Interpolate the 4 corners of this tile from the merged quad corners
                float x00 = interpolate(c, fu0, fv0, 0), y00 = interpolate(c, fu0, fv0, 1), z00 = interpolate(c, fu0, fv0, 2);
                float x10 = interpolate(c, fu1, fv0, 0), y10 = interpolate(c, fu1, fv0, 1), z10 = interpolate(c, fu1, fv0, 2);
                float x11 = interpolate(c, fu1, fv1, 0), y11 = interpolate(c, fu1, fv1, 1), z11 = interpolate(c, fu1, fv1, 2);
                float x01 = interpolate(c, fu0, fv1, 0), y01 = interpolate(c, fu0, fv1, 1), z01 = interpolate(c, fu0, fv1, 2);

                // Compute the world block position for this tile for lighting/tint
                int wx = tileBlockCoord(baseX, c, 0, quad.face().getStepX(), fu0, fv0);
                int wy = tileBlockCoord(baseY, c, 1, quad.face().getStepY(), fu0, fv0);
                int wz = tileBlockCoord(baseZ, c, 2, quad.face().getStepZ(), fu0, fv0);

                if (fullbright) {
                    java.util.Arrays.fill(lighting.brightness, 1.0f);
                    java.util.Arrays.fill(lighting.lightmap, 0xF000F0);
                } else {
                    GreedyLighting.computeTileLighting(world, quad.state(), quad.face(), wx, wy, wz, lighting);
                }
                int tint = applyTint ? tintColorForTile(quad.state(), world, wx, wy, wz, tintPos, blockColors, tintIndex) : 0xFFFFFF;
                float tintR = ((tint >> 16) & 0xFF) / 255.0f;
                float tintG = ((tint >> 8) & 0xFF) / 255.0f;
                float tintB = (tint & 0xFF) / 255.0f;

                if (fullbright) {
                    // Keep the emissive companion in front of the base face even at long range,
                    // where a 0.001-block separation is below depth-buffer precision.
                    x00 += nx * 0.05f; y00 += ny * 0.05f; z00 += nz * 0.05f;
                    x10 += nx * 0.05f; y10 += ny * 0.05f; z10 += nz * 0.05f;
                    x11 += nx * 0.05f; y11 += ny * 0.05f; z11 += nz * 0.05f;
                    x01 += nx * 0.05f; y01 += ny * 0.05f; z01 += nz * 0.05f;
                }
                consumer.addVertex(x00, y00, z00)
                        .setColor(lighting.brightness[0] * tintR, lighting.brightness[0] * tintG, lighting.brightness[0] * tintB, 1.0f)
                        .setUv(u0, vv0).setLight(lighting.lightmap[0]).setNormal(nx, ny, nz);
                consumer.addVertex(x10, y10, z10)
                        .setColor(lighting.brightness[1] * tintR, lighting.brightness[1] * tintG, lighting.brightness[1] * tintB, 1.0f)
                        .setUv(u1, vv0).setLight(lighting.lightmap[1]).setNormal(nx, ny, nz);
                consumer.addVertex(x11, y11, z11)
                        .setColor(lighting.brightness[2] * tintR, lighting.brightness[2] * tintG, lighting.brightness[2] * tintB, 1.0f)
                        .setUv(u1, vv1).setLight(lighting.lightmap[2]).setNormal(nx, ny, nz);
                consumer.addVertex(x01, y01, z01)
                        .setColor(lighting.brightness[3] * tintR, lighting.brightness[3] * tintG, lighting.brightness[3] * tintB, 1.0f)
                        .setUv(u0, vv1).setLight(lighting.lightmap[3]).setNormal(nx, ny, nz);

                count++;
            }
        }
        return count;
    }

    /**
     * Bilinear interpolation within the merged quad's 4 corners.
     * c is a 12-element array: [x0,y0,z0, x1,y1,z1, x2,y2,z2, x3,y3,z3]
     * Corners are ordered: 0=bottom-left, 1=bottom-right, 2=top-right, 3=top-left
     * fu goes along edge 0->1, fv goes along edge 0->3.
     */
    @Unique
    private static float interpolate(float[] c, float fu, float fv, int axis) {
        float bottom = c[0 + axis] + (c[3 + axis] - c[0 + axis]) * fu;
        float top    = c[9 + axis] + (c[6 + axis] - c[9 + axis]) * fu;
        return bottom + (top - bottom) * fv;
    }

    /**
     * Compute the world block coordinate for a tile at fractional position (fu, fv)
     * within the merged quad. We floor the interpolated local position and offset
     * inward along the face normal so the lighting sample hits the correct block.
     */
    @Unique
    private static int tileBlockCoord(int base, float[] c, int axis, int faceStep, float fu, float fv) {
        float center = interpolate(c, fu + 0.001f, fv + 0.001f, axis);
        int local = (int) Math.floor(center);
        // Offset by face step to sample the block behind the face (the solid block)
        if (faceStep > 0) {
            local = Math.max(0, local - 1 + faceStep);
        }
        return base + local;
    }

    @Unique
    private static int[][] greedyMeshing$cornerBlockPositions(GreedyMesher.GreedyQuad quad, int baseX, int baseY, int baseZ) {
        int[][] cb = new int[4][3];
        greedyMeshing$cornerBlockPositionsInto(quad, baseX, baseY, baseZ, cb);
        return cb;
    }

    @Unique
    private static void greedyMeshing$cornerBlockPositionsInto(GreedyMesher.GreedyQuad quad, int baseX, int baseY, int baseZ, int[][] cb) {
        int x = baseX + quad.x();
        int y = baseY + quad.y();
        int z = baseZ + quad.z();
        int w = quad.width();
        int h = quad.height();
        switch (quad.face()) {
            case NORTH -> {
                cb[0][0]=x+w-1; cb[0][1]=y;     cb[0][2]=z;
                cb[1][0]=x;     cb[1][1]=y;     cb[1][2]=z;
                cb[2][0]=x;     cb[2][1]=y+h-1; cb[2][2]=z;
                cb[3][0]=x+w-1; cb[3][1]=y+h-1; cb[3][2]=z;
            }
            case SOUTH -> {
                cb[0][0]=x;     cb[0][1]=y;     cb[0][2]=z;
                cb[1][0]=x+w-1; cb[1][1]=y;     cb[1][2]=z;
                cb[2][0]=x+w-1; cb[2][1]=y+h-1; cb[2][2]=z;
                cb[3][0]=x;     cb[3][1]=y+h-1; cb[3][2]=z;
            }
            case WEST -> {
                cb[0][0]=x; cb[0][1]=y;     cb[0][2]=z;
                cb[1][0]=x; cb[1][1]=y;     cb[1][2]=z+w-1;
                cb[2][0]=x; cb[2][1]=y+h-1; cb[2][2]=z+w-1;
                cb[3][0]=x; cb[3][1]=y+h-1; cb[3][2]=z;
            }
            case EAST -> {
                cb[0][0]=x; cb[0][1]=y;     cb[0][2]=z+w-1;
                cb[1][0]=x; cb[1][1]=y;     cb[1][2]=z;
                cb[2][0]=x; cb[2][1]=y+h-1; cb[2][2]=z;
                cb[3][0]=x; cb[3][1]=y+h-1; cb[3][2]=z+w-1;
            }
            case DOWN -> {
                cb[0][0]=x;     cb[0][1]=y; cb[0][2]=z;
                cb[1][0]=x+w-1; cb[1][1]=y; cb[1][2]=z;
                cb[2][0]=x+w-1; cb[2][1]=y; cb[2][2]=z+h-1;
                cb[3][0]=x;     cb[3][1]=y; cb[3][2]=z+h-1;
            }
            case UP -> {
                cb[0][0]=x;     cb[0][1]=y; cb[0][2]=z+h-1;
                cb[1][0]=x+w-1; cb[1][1]=y; cb[1][2]=z+h-1;
                cb[2][0]=x+w-1; cb[2][1]=y; cb[2][2]=z;
                cb[3][0]=x;     cb[3][1]=y; cb[3][2]=z;
            }
        }
    }

    @Unique
    private static int tintColorForTile(
            BlockState state,
            BlockAndTintGetter world,
            int worldX,
            int worldY,
            int worldZ,
            BlockPos.MutableBlockPos samplePos,
            BlockColors blockColors,
            int tintIndex
    ) {
        samplePos.set(worldX, worldY, worldZ);
        if (state.is(Blocks.WATER)) {
            //? if UNOBFUSCATED {
            /*// Not yet wired up on this branch — see GreedyEligibility.isGreedyWaterSource, which
            // always returns false here, so this is unreachable rather than a behavior change.
            return 0xFFFFFF;
            *///?} else {
            // Water's biome tint is applied by the fluid renderer directly (BiomeColors.getAverageWaterColor),
            // not through the generic BlockColors registry the rest of this method uses.
            FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(Fluids.WATER);
            return handler != null ? handler.getFluidColor(world, samplePos, state.getFluidState()) : 0xFFFFFF;
            //?}
        }
        //? if UNOBFUSCATED {
        /*// A model can carry a tintindex the block has no tint source for (resource-pack models,
        // issue #21); the legacy getColor path reports that as -1, so treat null the same way.
        var tintSource = blockColors.getTintSource(state, tintIndex);
        int tint = tintSource == null ? -1 : tintSource.colorInWorld(state, world, samplePos);
        *///?} else {
        int tint = blockColors.getColor(state, world, samplePos, tintIndex);
        //?}
        return tint == -1 ? 0xFFFFFF : tint;
    }

    /**
     * The height of a water quad's top edge: a full block (1.0) for every non-water quad AND for
     * water that has more water directly above it (an internal boundary, not a real surface — vanilla
     * renders these at full height too, see LiquidBlockRenderer.getHeight's "covered" branch). Only a
     * water block genuinely exposed to something other than water above uses its own (usually ~0.889)
     * exposed-surface height. Must be checked per quad, NOT inferred from `state.is(Blocks.WATER)`
     * alone — a submerged water block still has BlockState water/LEVEL=0 like a surface block, so
     * blindly shrinking every water quad left a ~0.11-block gap at every internal layer boundary in
     * water deeper than 1 block (issue: merged water quads left gaps in multi-layer-deep water).
     */
    @Unique
    private static float greedyMeshing$waterSurfaceTop(
            BlockAndTintGetter world, GreedyMesher.GreedyQuad quad, int baseX, int baseY, int baseZ,
            BlockPos.MutableBlockPos scratch
    ) {
        if (!quad.state().is(Blocks.WATER)) {
            return 1.0f;
        }
        scratch.set(baseX + quad.x(), baseY + quad.y() + 1, baseZ + quad.z());
        if (world.getBlockState(scratch).getFluidState().getType() == Fluids.WATER) {
            return 1.0f;
        }
        return quad.state().getFluidState().getOwnHeight();
    }

    @Unique
    private static float[] corners(GreedyMesher.GreedyQuad quad, float top) {
        float[] c = new float[12];
        cornersInto(quad, c, top);
        return c;
    }

    @Unique
    private static void cornersInto(GreedyMesher.GreedyQuad quad, float[] c, float top) {
        float x0 = quad.x();
        float y0 = quad.y();
        float z0 = quad.z();
        float x1, y1, z1;
        switch (quad.face()) {
            case NORTH -> {
                x1 = x0 + quad.width(); y1 = y0 + quad.height() - 1 + top; z1 = z0;
                c[0]=x1; c[1]=y0; c[2]=z1; c[3]=x0; c[4]=y0; c[5]=z1;
                c[6]=x0; c[7]=y1; c[8]=z1; c[9]=x1; c[10]=y1; c[11]=z1;
            }
            case SOUTH -> {
                x1 = x0 + quad.width(); y1 = y0 + quad.height() - 1 + top; z1 = z0 + 1.0f;
                c[0]=x0; c[1]=y0; c[2]=z1; c[3]=x1; c[4]=y0; c[5]=z1;
                c[6]=x1; c[7]=y1; c[8]=z1; c[9]=x0; c[10]=y1; c[11]=z1;
            }
            case WEST -> {
                y1 = y0 + quad.height() - 1 + top; z1 = z0 + quad.width(); x1 = x0;
                c[0]=x1; c[1]=y0; c[2]=z0; c[3]=x1; c[4]=y0; c[5]=z1;
                c[6]=x1; c[7]=y1; c[8]=z1; c[9]=x1; c[10]=y1; c[11]=z0;
            }
            case EAST -> {
                y1 = y0 + quad.height() - 1 + top; z1 = z0 + quad.width(); x1 = x0 + 1.0f;
                c[0]=x1; c[1]=y0; c[2]=z1; c[3]=x1; c[4]=y0; c[5]=z0;
                c[6]=x1; c[7]=y1; c[8]=z0; c[9]=x1; c[10]=y1; c[11]=z1;
            }
            case DOWN -> {
                x1 = x0 + quad.width(); z1 = z0 + quad.height(); y1 = y0;
                c[0]=x0; c[1]=y1; c[2]=z0; c[3]=x1; c[4]=y1; c[5]=z0;
                c[6]=x1; c[7]=y1; c[8]=z1; c[9]=x0; c[10]=y1; c[11]=z1;
            }
            case UP -> {
                x1 = x0 + quad.width(); z1 = z0 + quad.height(); y1 = y0 + top;
                c[0]=x0; c[1]=y1; c[2]=z1; c[3]=x1; c[4]=y1; c[5]=z1;
                c[6]=x1; c[7]=y1; c[8]=z0; c[9]=x0; c[10]=y1; c[11]=z0;
            }
        }
    }

    //? if UNOBFUSCATED {
    /*@Unique
    private record FaceAppearance(TextureAtlasSprite sprite, boolean tinted, ChunkSectionLayer layer, int tintIndex) {
    }
    *///?} else {
    @Unique
    private record FaceAppearance(TextureAtlasSprite sprite, boolean tinted, int tintIndex) {
    }
    //?}

}
//?}
