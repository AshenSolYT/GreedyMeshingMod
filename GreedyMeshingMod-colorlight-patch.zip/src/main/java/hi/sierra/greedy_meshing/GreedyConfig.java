package hi.sierra.greedy_meshing;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class GreedyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("greedy_meshing.json");
    private static Data data = new Data();
    private static volatile Runnable applyListener;

    private GreedyConfig() {
    }

    public static void load() {
        if (!Files.exists(CONFIG_PATH)) {
            save();
            return;
        }

        try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
            Data loaded = GSON.fromJson(reader, Data.class);
            if (loaded != null) {
                loaded.clamp();
                data = loaded;
            }
        } catch (IOException ignored) {
        }
    }

    public static void save() {
        data.clamp();
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(data, writer);
            }
        } catch (IOException ignored) {
        }
    }

    public static boolean enabled() {
        return data.enabled;
    }

    public static boolean aggressiveGreedy() {
        return data.aggressiveGreedy;
    }

    public static boolean greedyWater() {
        return data.greedyWater;
    }

    public static boolean mergeOrientedBlocks() {
        return data.mergeOrientedBlocks;
    }

    /** Merge blocks that a resource pack's CTM/random-texture properties match, instead of leaving
     *  them to the normal renderer. Their per-position texture can't survive merging, so this
     *  trades the effect for performance everywhere (issue #20). */
    public static boolean mergeCtmBlocks() {
        return data.mergeCtmBlocks;
    }

    public static boolean gpuCrackFix() {
        return data.gpuCrackFix;
    }

    public static boolean debugWireframe() {
        return data.debugWireframe;
    }

    public static boolean debugComparison() {
        return data.debugComparison;
    }

    public static boolean debugTrianglesHud() {
        return data.debugTrianglesHud;
    }

    public static boolean debugScreenOverlay() {
        return data.debugScreenOverlay;
    }

    public static float meshOpacity() {
        return data.meshOpacity;
    }

    /** Sections closer than this many chunks to the player render per-block instead of merged
     *  (0 = always merge, the historical default). See issue #19: merging doesn't preserve
     *  per-block texture rotation, which is only noticeable up close. */
    public static int minMeshDistance() {
        return data.minMeshDistance;
    }

    /** Short, human-readable summary of the non-default toggles currently in effect, for the F3 overlay. */
    public static String activeSettingsSummary() {
        StringBuilder sb = new StringBuilder();
        if (data.aggressiveGreedy) append(sb, "Aggressive");
        if (data.mergeOrientedBlocks) append(sb, "MergeOriented");
        if (data.mergeCtmBlocks) append(sb, "MergeCTM");
        if (data.gpuCrackFix) append(sb, "CrackFix");
        if (data.greedyWater) append(sb, "GreedyWater");
        if (data.minMeshDistance > 0) append(sb, "MinMerge " + data.minMeshDistance);
        return sb.length() == 0 ? "(defaults)" : sb.toString();
    }

    private static void append(StringBuilder sb, String flag) {
        if (sb.length() > 0) {
            sb.append(", ");
        }
        sb.append(flag);
    }

    public static Data snapshot() {
        Data copy = new Data();
        copy.enabled = data.enabled;
        copy.aggressiveGreedy = data.aggressiveGreedy;
        copy.greedyWater = data.greedyWater;
        copy.mergeOrientedBlocks = data.mergeOrientedBlocks;
        copy.mergeCtmBlocks = data.mergeCtmBlocks;
        copy.gpuCrackFix = data.gpuCrackFix;
        copy.debugWireframe = data.debugWireframe;
        copy.debugComparison = data.debugComparison;
        copy.debugTrianglesHud = data.debugTrianglesHud;
        copy.debugScreenOverlay = data.debugScreenOverlay;
        copy.meshOpacity = data.meshOpacity;
        copy.minMeshDistance = data.minMeshDistance;
        return copy;
    }

    public static void apply(Data newData) {
        newData.clamp();
        data = newData;
        // isGreedyOpaqueCube() consults mergeOrientedBlocks, so its per-BlockState cache would
        // otherwise keep serving verdicts from the previous setting.
        GreedyEligibility.clearCache();
        save();
        Runnable listener = applyListener;
        if (listener != null) listener.run();
    }

    /** Called after every apply(), so a screen that keeps its own draft (Sodium's) can re-read the
     *  saved values when another screen (Cloth's) changed them. Single slot: the latest wins. */
    public static void setApplyListener(Runnable listener) {
        applyListener = listener;
    }

    public static final class Data {
        public boolean enabled = true;
        /** Merge coplanar faces of the same block regardless of their ambient-occlusion signature,
         *  producing the largest possible quads ("absolute" greedy). Fewer quads at the cost of
         *  slightly coarser per-vertex lighting on big merged surfaces. */
        public boolean aggressiveGreedy = false;
        /** Merge flat interior-lake/ocean still-water top, side, and bottom faces into larger quads,
         *  the same way solid blocks are merged. Only applies where the water surface is provably
         *  flat (no slope) — shorelines and flowing water always fall back to normal per-block
         *  rendering, so this never changes how non-flat water looks. No effect on VulkanMod (its
         *  per-quad translucency depth-sort breaks visibly when water is merged into large quads). */
        public boolean greedyWater = false;
        /** Allow blocks carrying an orientation property (facing/axis/rotation) to merge when their
         *  baked model is verified to be six full unit faces with the standard cube UV mapping.
         *  The property name alone is a blunt proxy (plenty of such blocks are plain cubes), but
         *  the ones that are not would render with stretched or rotated textures when merged, so
         *  admission is gated on inspecting the actual model. Experimental, off by default. */
        public boolean mergeOrientedBlocks = false;
        /** Merge CTM/random-texture blocks too (off = they stay on the normal render path). */
        public boolean mergeCtmBlocks = false;
        /** Nudges a merged quad's outer-boundary vertices outward by a small epsilon to avoid
         *  view-dependent raster cracks ("T-junction gaps") seen on some mobile and desktop GPU
         *  drivers (e.g. Apple M-series). Adds no geometry, so it's cheap enough to default on. */
        public boolean gpuCrackFix = true;
        public boolean debugWireframe = false;
        public boolean debugComparison = false;
        public boolean debugTrianglesHud = false;
        public boolean debugScreenOverlay = true;
        public float meshOpacity = 0.35f;
        /** Chunk radius around the player exempt from merging (0 = always merge). */
        public int minMeshDistance = 0;
        public void clamp() {
            if (meshOpacity < 0.0f) {
                meshOpacity = 0.0f;
            } else if (meshOpacity > 1.0f) {
                meshOpacity = 1.0f;
            }
            if (minMeshDistance < 0) {
                minMeshDistance = 0;
            } else if (minMeshDistance > 32) {
                minMeshDistance = 32;
            }
        }
    }
}
