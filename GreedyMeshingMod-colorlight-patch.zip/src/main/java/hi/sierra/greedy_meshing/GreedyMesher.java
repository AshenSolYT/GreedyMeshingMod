package hi.sierra.greedy_meshing;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

/**
 * Greedy meshing for 16x16x16 chunk sections.
 * Merges coplanar block faces of the same type into larger quads.
 */
public final class GreedyMesher {
    public static final int SECTION_SIZE = 16;
    private static final int TOTAL_BLOCKS = SECTION_SIZE * SECTION_SIZE * SECTION_SIZE;
    private static final Direction[] ALL_FACES = Direction.values();
    private static final Logger LOGGER = LoggerFactory.getLogger("greedy_meshing");
    private static volatile boolean capWarned = false;

    /**
     * Pre-computed lookup: for each face direction and each plane depth,
     * maps (row, col) in the 2D sweep to a 3D block index.
     * Layout: [face][depth][row * 16 + col] -> block index
     */
    private static final int[][][] SWEEP_TO_BLOCK = buildSweepTable();

    /**
     * Inverse of {@link #SWEEP_TO_BLOCK}: for each face, maps a block index back to its packed
     * sweep coordinate {@code (depth << 8) | (row << 4) | col}. This lets the binary sweep walk
     * only the set bits of the visibility mask instead of probing all 4096 cells per face.
     */
    private static final int[][] BLOCK_TO_SWEEP = buildInverseSweepTable();

    private static final ThreadLocal<SweepState> SWEEP_TL = ThreadLocal.withInitial(SweepState::new);
    private static final ThreadLocal<BinarySweepState> BIN_SWEEP_TL = ThreadLocal.withInitial(BinarySweepState::new);

    private GreedyMesher() {}

    // ── Public entry points ──────────────────────────────────────────

    public static List<GreedyQuad> mesh(BlockState[] blocks, FaceVisibility vis) {
        return sweep(blocks, vis, (ox, oy, oz, cx, cy, cz, dir, st) -> true);
    }

    public static List<GreedyQuad> mesh(BlockState[] blocks, FaceVisibility vis, MergeKeyProvider keys) {
        return sweep(blocks, vis,
                (ox, oy, oz, cx, cy, cz, dir, st) ->
                        keys.mergeKey(cx, cy, cz, dir, st) == keys.mergeKey(ox, oy, oz, dir, st));
    }

    public static List<GreedyQuad> mesh(BlockState[] blocks, FaceVisibility vis, MergePredicate pred) {
        return sweep(blocks, vis, pred);
    }

    public static List<GreedyQuad> mesh(BlockState[] blocks, BitSet[] faceMasks) {
        return binarySweep(blocks, faceMasks, null);
    }

    public static List<GreedyQuad> mesh(BlockState[] blocks, BitSet[] faceMasks, MergePredicate pred) {
        return binarySweep(blocks, faceMasks, pred);
    }

    public static List<GreedyQuad> meshWithKeys(BlockState[] blocks, BitSet[] faceMasks, long[][] mergeKeys) {
        return binaryKeyedSweep(blocks, faceMasks, mergeKeys);
    }

    // ── Scalar sweep (callback-based visibility) ─────────────────────

    private static List<GreedyQuad> sweep(
            BlockState[] blocks, FaceVisibility vis, MergePredicate pred) {

        List<GreedyQuad> out = new ArrayList<>();
        SweepState st = SWEEP_TL.get();
        boolean[] done = st.acquire();

        for (Direction dir : ALL_FACES) {
            int fi = dir.ordinal();
            int[][] table = SWEEP_TO_BLOCK[fi];

            for (int depth = 0; depth < SECTION_SIZE; depth++) {
                int[] lookup = table[depth];

                for (int row = 0; row < SECTION_SIZE; row++) {
                    for (int col = 0; col < SECTION_SIZE; ) {
                        int bi = lookup[row * SECTION_SIZE + col];
                        int slot = fi * TOTAL_BLOCKS + bi;

                        if (done[slot]) { col++; continue; }

                        BlockState block = blocks[bi];
                        int bx = bi & 0xF, by = (bi >> 8) & 0xF, bz = (bi >> 4) & 0xF;

                        if (block == null || !vis.isVisibleFace(bx, by, bz, dir, block)) {
                            done[slot] = true;
                            col++;
                            continue;
                        }

                        // Expand width (along col axis)
                        int w = 1;
                        while (col + w < SECTION_SIZE) {
                            int ni = lookup[row * SECTION_SIZE + col + w];
                            int ns = fi * TOTAL_BLOCKS + ni;
                            if (done[ns]) break;
                            BlockState nb = blocks[ni];
                            if (nb != block) break;
                            int nx = ni & 0xF, ny = (ni >> 8) & 0xF, nz = (ni >> 4) & 0xF;
                            if (!vis.isVisibleFace(nx, ny, nz, dir, nb)
                                    || !pred.canMerge(bx, by, bz, nx, ny, nz, dir, nb)) break;
                            w++;
                        }

                        // Expand height (along row axis)
                        int h = 1;
                        outer:
                        while (row + h < SECTION_SIZE) {
                            for (int dc = 0; dc < w; dc++) {
                                int ni = lookup[(row + h) * SECTION_SIZE + col + dc];
                                int ns = fi * TOTAL_BLOCKS + ni;
                                if (done[ns]) break outer;
                                BlockState nb = blocks[ni];
                                if (nb != block) break outer;
                                int nx = ni & 0xF, ny = (ni >> 8) & 0xF, nz = (ni >> 4) & 0xF;
                                if (!vis.isVisibleFace(nx, ny, nz, dir, nb)
                                        || !pred.canMerge(bx, by, bz, nx, ny, nz, dir, nb)) break outer;
                            }
                            h++;
                        }

                        // Mark merged cells
                        for (int dr = 0; dr < h; dr++) {
                            for (int dc = 0; dc < w; dc++) {
                                done[fi * TOTAL_BLOCKS + lookup[(row + dr) * SECTION_SIZE + col + dc]] = true;
                            }
                        }

                        out.add(new GreedyQuad(dir, bx, by, bz, w, h, block));
                        col += w;
                    }
                }
            }
        }

        return out;
    }

    // ── Binary sweep (BitSet visibility, optional predicate) ─────────

    private static List<GreedyQuad> binarySweep(
            BlockState[] blocks, BitSet[] faceMasks, MergePredicate pred) {

        List<GreedyQuad> out = new ArrayList<>();
        BinarySweepState bw = BIN_SWEEP_TL.get();
        int[] rows = bw.rows;
        long[] keys = bw.keys;
        int[] origins = bw.origins;

        for (Direction dir : ALL_FACES) {
            int fi = dir.ordinal();
            BitSet visible = faceMasks[fi];
            int[][] table = SWEEP_TO_BLOCK[fi];

            for (int depth = 0; depth < SECTION_SIZE; depth++) {
                int[] lookup = table[depth];
                int nGroups = 0;

                // Bucket visible cells by BlockState identity
                for (int row = 0; row < SECTION_SIZE; row++) {
                    for (int col = 0; col < SECTION_SIZE; col++) {
                        int bi = lookup[row * SECTION_SIZE + col];
                        BlockState block = blocks[bi];
                        if (block == null || !visible.get(bi)) continue;

                        long key = System.identityHashCode(block);
                        int gid = -1;
                        for (int g = 0; g < nGroups; g++) {
                            if (keys[g] == key) { gid = g; break; }
                        }
                        if (gid == -1) {
                            if (nGroups >= BinarySweepState.CAP) break;
                            gid = nGroups++;
                            keys[gid] = key;
                            origins[gid] = bi;
                            for (int r = 0; r < SECTION_SIZE; r++) rows[gid * SECTION_SIZE + r] = 0;
                        }
                        rows[gid * SECTION_SIZE + row] |= 1 << col;
                    }
                }

                // Greedy merge each group
                for (int g = 0; g < nGroups; g++) {
                    int base = g * SECTION_SIZE;
                    BlockState block = blocks[origins[g]];

                    for (int row = 0; row < SECTION_SIZE; row++) {
                        int bits = rows[base + row];
                        while (bits != 0) {
                            int col = Integer.numberOfTrailingZeros(bits);
                            int w = Integer.numberOfTrailingZeros(~(bits >>> col));

                            if (pred != null) {
                                int si = lookup[row * SECTION_SIZE + col];
                                int sx = si & 0xF, sy = (si >> 8) & 0xF, sz = (si >> 4) & 0xF;
                                int rw = 1;
                                for (int dc = 1; dc < w; dc++) {
                                    int ni = lookup[row * SECTION_SIZE + col + dc];
                                    int nx = ni & 0xF, ny = (ni >> 8) & 0xF, nz = (ni >> 4) & 0xF;
                                    if (!pred.canMerge(sx, sy, sz, nx, ny, nz, dir, block)) break;
                                    rw++;
                                }
                                w = rw;
                            }

                            int span = ((1 << w) - 1) << col;
                            int h = 1;
                            while (row + h < SECTION_SIZE) {
                                if ((rows[base + row + h] & span) != span) break;
                                if (pred != null) {
                                    int si = lookup[row * SECTION_SIZE + col];
                                    int sx = si & 0xF, sy = (si >> 8) & 0xF, sz = (si >> 4) & 0xF;
                                    boolean ok = true;
                                    for (int dc = 0; dc < w; dc++) {
                                        int ni = lookup[(row + h) * SECTION_SIZE + col + dc];
                                        int nx = ni & 0xF, ny = (ni >> 8) & 0xF, nz = (ni >> 4) & 0xF;
                                        if (!pred.canMerge(sx, sy, sz, nx, ny, nz, dir, block)) { ok = false; break; }
                                    }
                                    if (!ok) break;
                                }
                                h++;
                            }

                            for (int dr = 0; dr < h; dr++) rows[base + row + dr] &= ~span;

                            int qi = lookup[row * SECTION_SIZE + col];
                            out.add(new GreedyQuad(dir,
                                    qi & 0xF, (qi >> 8) & 0xF, (qi >> 4) & 0xF,
                                    w, h, block));

                            bits = rows[base + row];
                        }
                    }
                }
            }
        }
        return out;
    }

    // ── Binary keyed sweep (pre-computed merge keys, pure bitwise) ───

    private static List<GreedyQuad> binaryKeyedSweep(
            BlockState[] blocks, BitSet[] faceMasks, long[][] mergeKeys) {

        // Pre-sized: a merged section routinely emits a few hundred quads, and the default
        // capacity of 10 makes chunk-build threads walk a chain of array copies to get there.
        List<GreedyQuad> out = new ArrayList<>(256);
        BinarySweepState bw = BIN_SWEEP_TL.get();
        int[] rows = bw.rows;
        long[] keys = bw.keys;
        int[] origins = bw.origins;

        int[] depthCells = bw.depthCells;
        int[] depthCounts = bw.depthCounts;

        for (Direction dir : ALL_FACES) {
            int fi = dir.ordinal();
            BitSet visible = faceMasks[fi];
            // Whole faces are commonly fully culled (interior sections, flat terrain seen from
            // above). Skipping them here avoids 16 depth slices of setup apiece.
            if (visible.isEmpty()) continue;

            long[] faceKeys = mergeKeys[fi];
            int[][] table = SWEEP_TO_BLOCK[fi];
            int[] inverse = BLOCK_TO_SWEEP[fi];

            // Bucket the visible faces by depth slice by walking set bits only. Cost is now
            // proportional to the number of visible faces rather than a flat 4096 probes per face.
            java.util.Arrays.fill(depthCounts, 0);
            for (int bi = visible.nextSetBit(0); bi >= 0; bi = visible.nextSetBit(bi + 1)) {
                if (blocks[bi] == null) continue;
                int depth = inverse[bi] >>> 8;
                depthCells[(depth << 8) + depthCounts[depth]++] = bi;
            }

            for (int depth = 0; depth < SECTION_SIZE; depth++) {
                int cellCount = depthCounts[depth];
                if (cellCount == 0) continue;

                int[] lookup = table[depth];
                int cellBase = depth << 8;
                int nGroups = 0;
                int lastGid = -1;
                int stamp = bw.nextStamp();
                int[] hStamp = bw.hashStamp;
                long[] hKey = bw.hashKey;
                int[] hVal = bw.hashVal;

                for (int c = 0; c < cellCount; c++) {
                    int bi = depthCells[cellBase + c];
                    BlockState block = blocks[bi];
                    int packed = inverse[bi];
                    int row = (packed >>> 4) & 0xF;
                    int col = packed & 0xF;

                    long ck = ((long) System.identityHashCode(block) << 32) | (faceKeys[bi] & 0xFFFFFFFFL);
                    int gid = -1;
                    int slot = -1;
                    // Runs of one block state dominate, so check the previous group first. Otherwise
                    // probe a small open-addressed table: a slice has at most 256 cells, so a 512-slot
                    // table stays at most half full and lookups stay O(1) where the old linear scan was
                    // O(groups) per cell (it dominated sections with many AO/light variants).
                    if (lastGid >= 0 && keys[lastGid] == ck) {
                        gid = lastGid;
                    } else {
                        slot = (int) ((ck * 0x9E3779B97F4A7C15L) >>> (64 - BinarySweepState.HASH_BITS));
                        while (hStamp[slot] == stamp) {
                            if (hKey[slot] == ck) { gid = hVal[slot]; break; }
                            slot = (slot + 1) & BinarySweepState.HASH_MASK;
                        }
                    }
                    if (gid == -1) {
                        if (nGroups >= BinarySweepState.CAP) {
                            if (!capWarned) {
                                capWarned = true;
                                LOGGER.warn("Greedy Meshing: hit BinarySweepState.CAP ({}) distinct merge-key groups "
                                        + "in one depth-slice (face={}, depth={}): faces needing a further group in "
                                        + "this slice were skipped (not merged, not emitted). Prints once.",
                                        BinarySweepState.CAP, dir, depth);
                            }
                            continue;
                        }
                        gid = nGroups++;
                        keys[gid] = ck;
                        origins[gid] = bi;
                        hStamp[slot] = stamp;
                        hKey[slot] = ck;
                        hVal[slot] = gid;
                        for (int r = 0; r < SECTION_SIZE; r++) rows[gid * SECTION_SIZE + r] = 0;
                    }
                    lastGid = gid;
                    rows[gid * SECTION_SIZE + row] |= 1 << col;
                }

                for (int g = 0; g < nGroups; g++) {
                    int base = g * SECTION_SIZE;
                    BlockState block = blocks[origins[g]];

                    for (int row = 0; row < SECTION_SIZE; row++) {
                        int bits = rows[base + row];
                        while (bits != 0) {
                            int col = Integer.numberOfTrailingZeros(bits);
                            int w = Integer.numberOfTrailingZeros(~(bits >>> col));
                            int span = ((1 << w) - 1) << col;

                            int h = 1;
                            while (row + h < SECTION_SIZE
                                    && (rows[base + row + h] & span) == span) h++;

                            for (int dr = 0; dr < h; dr++) rows[base + row + dr] &= ~span;

                            int qi = lookup[row * SECTION_SIZE + col];
                            out.add(new GreedyQuad(dir,
                                    qi & 0xF, (qi >> 8) & 0xF, (qi >> 4) & 0xF,
                                    w, h, block));

                            bits = rows[base + row];
                        }
                    }
                }
            }
        }
        return out;
    }

    // ── Utilities ────────────────────────────────────────────────────

    public static BitSet[] createFaceMaskArray() {
        BitSet[] masks = new BitSet[ALL_FACES.length];
        for (int i = 0; i < masks.length; i++) masks[i] = new BitSet(TOTAL_BLOCKS);
        return masks;
    }

    public static void clearFaceMaskArray(BitSet[] masks) {
        for (BitSet m : masks) m.clear();
    }

    public static int index(int x, int y, int z) {
        return (y << 8) | (z << 4) | x;
    }

    // ── Sweep-to-block lookup table ─────────────────────────────────

    private static int[][][] buildSweepTable() {
        int[][][] t = new int[ALL_FACES.length][SECTION_SIZE][SECTION_SIZE * SECTION_SIZE];
        for (Direction dir : ALL_FACES) {
            for (int depth = 0; depth < SECTION_SIZE; depth++) {
                for (int row = 0; row < SECTION_SIZE; row++) {
                    for (int col = 0; col < SECTION_SIZE; col++) {
                        int x, y, z;
                        switch (dir) {
                            case DOWN, UP     -> { x = col; y = depth; z = row; }
                            case NORTH, SOUTH -> { x = col; y = row;   z = depth; }
                            default           -> { x = depth; y = row; z = col; }
                        }
                        t[dir.ordinal()][depth][row * SECTION_SIZE + col] = index(x, y, z);
                    }
                }
            }
        }
        return t;
    }

    /** Derived from {@link #SWEEP_TO_BLOCK} rather than re-deriving the axis mapping by hand. */
    private static int[][] buildInverseSweepTable() {
        int[][] inv = new int[ALL_FACES.length][TOTAL_BLOCKS];
        for (int[] face : inv) {
            java.util.Arrays.fill(face, -1);
        }
        for (Direction dir : ALL_FACES) {
            int fi = dir.ordinal();
            for (int depth = 0; depth < SECTION_SIZE; depth++) {
                for (int row = 0; row < SECTION_SIZE; row++) {
                    for (int col = 0; col < SECTION_SIZE; col++) {
                        int bi = SWEEP_TO_BLOCK[fi][depth][row * SECTION_SIZE + col];
                        inv[fi][bi] = (depth << 8) | (row << 4) | col;
                    }
                }
            }
        }
        // The sweep table must be a bijection per face, or the sweep would read a bogus depth and
        // silently emit misplaced geometry. Fail at class-load instead, where it is diagnosable.
        for (int fi = 0; fi < inv.length; fi++) {
            for (int bi = 0; bi < TOTAL_BLOCKS; bi++) {
                if (inv[fi][bi] < 0) {
                    throw new IllegalStateException(
                            "Greedy Meshing: sweep table is not a bijection (face=" + fi + ", block=" + bi + ")");
                }
            }
        }
        return inv;
    }

    // ── Types ────────────────────────────────────────────────────────

    @FunctionalInterface
    public interface FaceVisibility {
        boolean isVisibleFace(int x, int y, int z, Direction face, BlockState state);
    }

    @FunctionalInterface
    public interface MergeKeyProvider {
        int mergeKey(int x, int y, int z, Direction face, BlockState state);
    }

    @FunctionalInterface
    public interface MergePredicate {
        boolean canMerge(int startX, int startY, int startZ,
                         int currentX, int currentY, int currentZ,
                         Direction face, BlockState state);
    }

    public record GreedyQuad(Direction face, int x, int y, int z,
                             int width, int height, BlockState state) {}

    // ── Thread-local work buffers ───────────────────────────────────

    private static final class SweepState {
        private final boolean[] used = new boolean[ALL_FACES.length * TOTAL_BLOCKS];

        boolean[] acquire() {
            java.util.Arrays.fill(used, false);
            return used;
        }
    }

    private static final class BinarySweepState {
        static final int CAP = 256;
        final int[] rows = new int[CAP * SECTION_SIZE];
        final long[] keys = new long[CAP];
        final int[] origins = new int[CAP];
        /** Visible block indices bucketed by depth slice: slot {@code depth * 256 + n}. */
        final int[] depthCells = new int[SECTION_SIZE * SECTION_SIZE * SECTION_SIZE];
        final int[] depthCounts = new int[SECTION_SIZE];

        /** Open-addressed group lookup for one depth slice; 512 slots for at most 256 cells. */
        static final int HASH_BITS = 9;
        static final int HASH_SIZE = 1 << HASH_BITS;
        static final int HASH_MASK = HASH_SIZE - 1;
        final int[] hashStamp = new int[HASH_SIZE];
        final long[] hashKey = new long[HASH_SIZE];
        final int[] hashVal = new int[HASH_SIZE];
        private int stamp;

        /** A fresh stamp invalidates every slot at once, so the table is never cleared per slice. */
        int nextStamp() {
            if (++stamp == Integer.MAX_VALUE) {
                java.util.Arrays.fill(hashStamp, 0);
                stamp = 1;
            }
            return stamp;
        }
    }
}
